"""
Shared recon pipeline — used by both the CLI (`reconai.cli`) and the web
GUI (`reconai.webapp`) so the two front-ends stay in sync and don't
duplicate orchestration logic.
"""

from __future__ import annotations

from typing import Callable, Optional

from reconai.modules import (
    ai_analysis,
    dnstwist_scan,
    email_harvest,
    github_leaks,
    heuristics,
    httpx_probe,
    shodan_recon,
    subdomain_enum,
    subfinder_recon,
    theharvester_recon,
    whois_asn,
)

ALL_MODULES = {"subdomains", "shodan", "emails"}  # default set
ENRICHMENT_MODULES = {"httpx", "whois", "typosquat", "github"}  # opt-in


def enumerate_subdomains(domain: str, log: Optional[Callable[[str], None]] = None) -> dict:
    """
    Passive subdomain enumeration merging crt.sh with subfinder (if
    installed), then resolving the combined, deduplicated name list once.
    """

    def _log(msg: str) -> None:
        if log:
            log(msg)

    _log(f"Querying crt.sh for {domain}...")
    crtsh_result = subdomain_enum.run(domain, resolve=False)
    names = set(crtsh_result["subdomains"])
    sources = {"crt.sh": len(names)}
    errors = list(crtsh_result.get("errors", []))

    subfinder_installed = subfinder_recon.is_installed()
    if subfinder_installed:
        _log("Running subfinder (passive)...")
        sf_result = subfinder_recon.run(domain)
        sources["subfinder"] = len(sf_result["subdomains"])
        names |= set(sf_result["subdomains"])
        errors.extend(sf_result.get("errors", []))
    else:
        _log(f"subfinder not installed, skipping. {subfinder_recon.install_hint()}")

    names.add(domain)
    _log(f"Resolving {len(names)} unique candidate subdomains...")
    live_hosts, dead_hosts = subdomain_enum.resolve_many(sorted(names))

    return {
        "domain": domain,
        "subdomain_count": len(names),
        "subdomains": sorted(names),
        "live_hosts": live_hosts,
        "dead_hosts": sorted(dead_hosts),
        "sources": sources,
        "tool_status": {"subfinder_installed": subfinder_installed},
        "errors": errors,
    }


def harvest_emails(
    domain: str,
    hunter_key: Optional[str] = None,
    known_names: Optional[list[str]] = None,
    log: Optional[Callable[[str], None]] = None,
) -> dict:
    """
    Email intelligence merging Hunter.io / pattern-generation with
    theHarvester (if installed).
    """

    def _log(msg: str) -> None:
        if log:
            log(msg)

    email_result = email_harvest.run(
        domain, hunter_api_key=hunter_key, known_names=known_names
    )

    theharvester_installed = theharvester_recon.is_installed()
    if theharvester_installed:
        _log("Running theHarvester (passive sources)...")
        th_result = theharvester_recon.run(domain)
        existing = {e["value"] for e in email_result["confirmed_emails"]}
        for addr in th_result["emails"]:
            if addr not in existing:
                email_result["confirmed_emails"].append(
                    {
                        "value": addr,
                        "type": None,
                        "first_name": None,
                        "last_name": None,
                        "position": None,
                        "confidence": None,
                        "source": "theHarvester",
                    }
                )
                existing.add(addr)
        email_result["harvester_hosts"] = th_result["hosts"]
        email_result["errors"].extend(th_result.get("errors", []))
    else:
        _log(f"theHarvester not installed, skipping. {theharvester_recon.install_hint()}")

    email_result["tool_status"] = {"theharvester_installed": theharvester_installed}
    return email_result


def run_full(
    domain: str,
    shodan_key: Optional[str] = None,
    hunter_key: Optional[str] = None,
    anthropic_key: Optional[str] = None,
    known_names: Optional[list[str]] = None,
    skip_ai: bool = False,
    modules: Optional[set[str]] = None,
    github_token: Optional[str] = None,
    homoglyph: bool = False,
    log: Optional[Callable[[str], None]] = None,
) -> dict:
    """
    Run the recon pipeline against `domain`.

    modules: subset of {"subdomains", "shodan", "emails"} plus the opt-in
    enrichment modules {"httpx", "whois", "typosquat", "github"}. Defaults
    to subdomains/shodan/emails. "shodan" will use the free InternetDB lookup unless
    `shodan_key` is set, in which case it uses the full paid Shodan API.
    """

    def _log(msg: str) -> None:
        if log:
            log(msg)

    active = modules if modules is not None else set(ALL_MODULES)
    aggregated: dict = {"target": domain}

    sub_result = None
    needs_hosts = bool(active & {"subdomains", "shodan", "httpx", "whois"})
    if needs_hosts:
        sub_result = enumerate_subdomains(domain, log=_log)
    if "subdomains" in active and sub_result:
        aggregated["subdomains"] = sub_result
        _log(
            f"Found {sub_result['subdomain_count']} subdomains "
            f"({len(sub_result['live_hosts'])} live, {len(sub_result['dead_hosts'])} dead)."
        )

    if "shodan" in active:
        ip_list = []
        if sub_result:
            ip_list = sorted(
                {ip for ips in sub_result["live_hosts"].values() for ip in ips}
            )
        source = "full Shodan API" if shodan_key else "free InternetDB"
        _log(f"Looking up exposed services via {source}...")
        shodan_result = shodan_recon.run(domain, api_key=shodan_key, ip_list=ip_list)
        aggregated["shodan"] = shodan_result
        _log(
            f"{len(shodan_result['hosts'])} host records returned "
            f"(source: {shodan_result['source']})."
        )

    if "emails" in active:
        email_result = harvest_emails(
            domain, hunter_key=hunter_key, known_names=known_names, log=_log
        )
        aggregated["emails"] = email_result
        _log(
            f"{len(email_result['confirmed_emails'])} confirmed, "
            f"{len(email_result['generated_candidates'])} generated candidates."
        )

    live_hosts = sub_result["live_hosts"] if sub_result else {}
    all_ips = sorted({ip for ips in live_hosts.values() for ip in ips})

    if "httpx" in active:
        _log(f"Probing {len(live_hosts)} live hosts over HTTP(S)...")
        aggregated["httpx"] = httpx_probe.run(list(live_hosts))
        hx = aggregated["httpx"]
        _log(f"{hx.get('responsive', 0)} hosts responded (engine: {hx.get('engine')}).")

    if "whois" in active:
        _log(f"RDAP/ASN lookups for {len(all_ips)} IPs...")
        aggregated["whois_asn"] = whois_asn.run(all_ips)
        _log(f"{len(aggregated['whois_asn']['by_asn'])} distinct ASNs.")

    if "typosquat" in active:
        _log("Generating and resolving lookalike domains (dnstwist)...")
        aggregated["typosquat"] = dnstwist_scan.run(domain, include_homoglyph=homoglyph)
        _log(f"{len(aggregated['typosquat'].get('registered', []))} registered lookalikes found.")

    if "github" in active:
        _log("Searching public GitHub code for leaks (rate-limited, ~1 min)...")
        aggregated["github"] = github_leaks.run(domain, github_token)
        _log(f"{len(aggregated['github'].get('hits', []))} GitHub hits.")

    aggregated["rule_findings"] = heuristics.run(aggregated)
    _log(f"{len(aggregated['rule_findings'])} rule-based findings.")

    if not skip_ai:
        _log("Running AI correlation & risk analysis...")
        ai_result = ai_analysis.run(aggregated, api_key=anthropic_key)
        aggregated["ai_analysis"] = ai_result
        if ai_result.get("error"):
            _log(f"AI analysis note: {ai_result['error']}")
        else:
            _log(
                f"{len(ai_result.get('risk_findings', []))} risk findings identified."
            )
    else:
        _log("Skipped AI analysis.")

    return aggregated
