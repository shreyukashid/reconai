"""
AI-powered analysis layer.

Improvements over v1:
  * compacts the raw data first (v1 dumped raw JSON, which was dominated by
    per-port Cloudflare/CDN rows and got truncated at 100k chars)
  * feeds Claude the rule-based findings + httpx/ASN/typosquat/GitHub data
  * clear, actionable errors (bad key, no credit, rate limit) instead of raw API dumps
  * tolerant JSON extraction
"""

from __future__ import annotations

import json
import re

from anthropic import Anthropic, APIStatusError, AuthenticationError, RateLimitError

MODEL = "claude-sonnet-5-5"

SYSTEM_PROMPT = """You are a security analyst reviewing OSINT recon data that was \
collected about an authorized target (the user's own org, or a client under signed scope).

Do:
1. Correlate across sources (e.g. a host with a login page + exposed service + CVE; \
a lookalike domain with MX records; leaked GitHub files + exposed hosts; ASN/hosting spread).
2. Rank the top risks by realistic exploitability. Ignore noise: CDN edge IPs \
(Cloudflare/Akamai/Fastly) showing many ports are normal and are NOT findings.
3. Do not repeat the rule-based findings verbatim; confirm, merge, re-rank or downgrade \
them, and add what rules cannot see. Never invent evidence not present in the data.
4. Give a 0-100 attack_surface_score (100 = worst) with one-line rationale.
5. Executive summary 3-6 sentences for a non-technical reader; concrete next steps.

Respond ONLY with valid JSON, no fences, no preamble:
{
  "executive_summary": "string",
  "attack_surface_score": 0,
  "score_rationale": "string",
  "risk_findings": [{"severity": "critical|high|medium|low", "finding": "string", "evidence": "string", "recommendation": "string"}],
  "correlations": ["string"],
  "next_steps": ["string"]
}"""


def _empty(error: str, raw: str | None = None) -> dict:
    return {"error": error, "raw_response": raw, "executive_summary": None, "attack_surface_score": None,
            "score_rationale": None, "risk_findings": [], "correlations": [], "next_steps": []}


def compact(data: dict) -> dict:
    """Shrink aggregated data to what a model actually needs."""
    out: dict = {"target": data.get("target")}
    s = data.get("subdomains")
    if s:
        out["subdomains"] = {
            "count": s.get("subdomain_count"), "sources": s.get("sources"),
            "live": s.get("live_hosts"), "dead_count": len(s.get("dead_hosts", [])),
            "dead_sample": s.get("dead_hosts", [])[:40],
        }
    sh = data.get("shodan")
    if sh:
        by_ip: dict = {}
        for h in sh.get("hosts", []):
            e = by_ip.setdefault(h.get("ip"), {"org": h.get("org"), "ports": set(), "products": set(),
                                               "vulns": set(), "tags": set(), "cpes": set()})
            e["ports"].update(h.get("ports") or ([h["port"]] if h.get("port") else []))
            if h.get("product"):
                e["products"].add(f"{h['product']} {h.get('version') or ''}".strip())
            e["vulns"].update(h.get("vulns") or [])
            e["tags"].update(h.get("tags") or [])
            e["cpes"].update(h.get("cpes") or [])
        out["shodan"] = {ip: {k: (sorted(v) if isinstance(v, set) else v) for k, v in e.items() if v}
                         for ip, e in by_ip.items()}
    em = data.get("emails")
    if em:
        out["emails"] = {"pattern": em.get("likely_pattern"), "confirmed_count": len(em.get("confirmed_emails", [])),
                         "confirmed_sample": [e["value"] for e in em.get("confirmed_emails", [])[:25]]}
    hx = data.get("httpx")
    if hx:
        out["http"] = [{k: r.get(k) for k in ("host", "status", "title", "server", "tech", "tls_days_left", "redirect")}
                       for r in hx.get("results", [])]
    wa = data.get("whois_asn")
    if wa:
        out["asn"] = {k: {"org": v["description"], "ips": v["ips"]} for k, v in wa.get("by_asn", {}).items()}
    ty = data.get("typosquat")
    if ty:
        out["typosquat"] = {"registered": ty.get("registered", [])[:40], "candidates": ty.get("candidates")}
    gh = data.get("github")
    if gh:
        out["github_hits"] = gh.get("hits", [])[:40]
    if data.get("rule_findings"):
        out["rule_based_findings"] = data["rule_findings"]
    return out


def _extract_json(text: str) -> dict:
    text = text.strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.M).strip()
    start, end = text.find("{"), text.rfind("}")
    return json.loads(text[start:end + 1])


def run(aggregated_data: dict, api_key: str | None) -> dict:
    if not api_key:
        return _empty("No ANTHROPIC_API_KEY configured; AI analysis skipped (rule-based findings still shown).")
    client = Anthropic(api_key=api_key.strip())
    payload = json.dumps(compact(aggregated_data), default=str, separators=(",", ":"))[:120000]
    text = ""
    try:
        resp = client.messages.create(
            model=MODEL, max_tokens=4000, system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": "Recon data (compacted JSON). Return only the JSON object.\n\n" + payload}],
        )
        text = "".join(b.text for b in resp.content if b.type == "text")
        return _extract_json(text)
    except AuthenticationError:
        return _empty("Anthropic rejected the API key (401). Check ANTHROPIC_API_KEY in your .env: no quotes/spaces, "
                      "key still active, copied from console.anthropic.com. (Claude.ai chat access and API keys are separate.)")
    except RateLimitError:
        return _empty("Anthropic rate limit hit (429). Retry in a minute.")
    except APIStatusError as e:
        hint = " Add credits at console.anthropic.com → Billing." if e.status_code == 400 and "credit" in str(e).lower() else ""
        return _empty(f"Anthropic API error {e.status_code}.{hint} {str(e)[:200]}")
    except ValueError as e:
        return _empty(f"Could not parse AI response as JSON: {e}", raw=text[:2000])
    except Exception as e:
        return _empty(f"AI analysis failed: {e}")
