"""
Port scanning (TCP connect scan).

⚠️ THIS IS ACTIVE RECONNAISSANCE, like dir_enum.py. It opens real TCP
connections directly to the target's IPs to see which ports answer. This
is fundamentally different from the passive modules (subdomains/shodan/
emails/whois/typosquat/github), which only query third-party public
records and never touch the target itself. httpx is semi-active (one GET
per host); this is more active still (many connection attempts per host).

Only run this against a target you own or have explicit, documented
authorization to test. As with dir_enum, this module itself does not
enforce that — the CLI and web GUI both require an explicit confirmation
step before calling it.

Uses nmap (SYN scan, service/version detection) if installed and runnable
without root (falls back cleanly otherwise), else a pure-Python threaded
TCP-connect scan with best-effort banner grab — no extra dependencies.
"""

from __future__ import annotations

import concurrent.futures
import shutil
import socket
import subprocess
import time
import xml.etree.ElementTree as ET

BINARY = "nmap"

# nmap's default top-100 TCP ports, minus a handful of noisy/slow ones —
# good signal-to-noise for an OSINT-style scan rather than an exhaustive one.
TOP_PORTS = [
    21, 22, 23, 25, 53, 80, 81, 88, 110, 111, 113, 119, 135, 139, 143, 161,
    179, 199, 389, 427, 443, 444, 445, 465, 513, 514, 515, 543, 544, 548,
    554, 587, 631, 646, 873, 990, 993, 995, 1025, 1026, 1027, 1028, 1029,
    1110, 1433, 1720, 1723, 1755, 1900, 2000, 2001, 2049, 2121, 2375, 2376,
    3000, 3128, 3268, 3306, 3389, 3690, 3986, 4000, 4443, 4567, 5000, 5040,
    5060, 5190, 5357, 5432, 5631, 5666, 5800, 5900, 5985, 5986, 6000, 6379,
    6646, 7070, 8000, 8008, 8009, 8080, 8081, 8443, 8888, 9000, 9090, 9100,
    9200, 9999, 10000, 27017, 32768, 49152, 49153, 49154, 49155, 49156, 49157,
]

SAFE_BANNER_PORTS = {21, 22, 25, 110, 143}  # servers that speak first on connect


def is_nmap_installed() -> bool:
    return shutil.which(BINARY) is not None


def _grab_banner(sock: socket.socket) -> str | None:
    try:
        sock.settimeout(1.5)
        data = sock.recv(256)
        return data.decode("utf-8", "ignore").strip().replace("\x00", "") or None
    except Exception:
        return None


def _scan_one(ip: str, port: int, timeout: float) -> dict | None:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            if s.connect_ex((ip, port)) != 0:
                return None
            banner = _grab_banner(s) if port in SAFE_BANNER_PORTS else None
            return {"ip": ip, "port": port, "state": "open", "banner": banner}
    except (socket.gaierror, OSError):
        return None


def _socket_scan(ips: list[str], ports: list[int], timeout: float, max_workers: int, rate_per_sec: int) -> list[dict]:
    open_ports: list[dict] = []
    jobs = [(ip, p) for ip in ips for p in ports]
    delay = (1.0 / rate_per_sec) if rate_per_sec else 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = []
        for ip, port in jobs:
            futures.append(pool.submit(_scan_one, ip, port, timeout))
            if delay:
                time.sleep(delay / max_workers)
        for f in concurrent.futures.as_completed(futures):
            r = f.result()
            if r:
                open_ports.append(r)
    return open_ports


def _nmap_scan(ips: list[str], ports: list[int], timeout: int) -> tuple[list[dict], list[str]]:
    errors: list[str] = []
    port_arg = ",".join(str(p) for p in ports)
    cmd = [BINARY, "-Pn", "-sT", "-T3", "--open", "-p", port_arg, "-sV", "--version-light", "-oX", "-", *ips]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return [], [f"nmap timed out after {timeout}s"]
    except Exception as e:
        return [], [f"nmap failed to run: {e}"]

    if not proc.stdout.strip():
        errors.append((proc.stderr or "nmap produced no output").strip()[:400])
        return [], errors

    results = []
    try:
        root = ET.fromstring(proc.stdout)
        for host in root.findall("host"):
            addr_el = host.find("address")
            ip = addr_el.get("addr") if addr_el is not None else None
            ports_el = host.find("ports")
            if ports_el is None:
                continue
            for p in ports_el.findall("port"):
                state = p.find("state")
                if state is None or state.get("state") != "open":
                    continue
                svc = p.find("service")
                results.append({
                    "ip": ip,
                    "port": int(p.get("portid")),
                    "state": "open",
                    "service": svc.get("name") if svc is not None else None,
                    "product": svc.get("product") if svc is not None else None,
                    "version": svc.get("version") if svc is not None else None,
                    "banner": None,
                })
    except ET.ParseError as e:
        errors.append(f"Could not parse nmap XML output: {e}")
    return results, errors


def run(
    ips: list[str],
    ports: list[int] | None = None,
    timeout: float = 2.0,
    max_workers: int = 100,
    rate_per_sec: int = 200,
    engine_timeout: int = 300,
) -> dict:
    """
    TCP-connect port scan of `ips`.

    Uses nmap (service/version detection) if available on PATH, otherwise
    a plain-socket threaded connect scan with best-effort banner grabs on
    a few text protocols. Returns open ports found, grouped by IP.
    """
    ips = sorted(set(ips))
    port_list = sorted(set(ports)) if ports else TOP_PORTS
    if not ips:
        return {"engine": None, "scanned_ips": 0, "ports_per_ip": len(port_list), "open_ports": [], "errors": ["No IPs to scan."]}

    if is_nmap_installed():
        results, errors = _nmap_scan(ips, port_list, engine_timeout)
        engine = "nmap"
        if not results and not errors:
            errors = []
    else:
        results = _socket_scan(ips, port_list, timeout, max_workers, rate_per_sec)
        errors = []
        engine = "python-socket (nmap not installed — no service/version detection)"

    results.sort(key=lambda r: (r["ip"], r["port"]))
    by_ip: dict[str, list[int]] = {}
    for r in results:
        by_ip.setdefault(r["ip"], []).append(r["port"])

    return {
        "engine": engine,
        "scanned_ips": len(ips),
        "ports_per_ip": len(port_list),
        "open_ports": results,
        "by_ip": by_ip,
        "errors": errors,
    }
