"""
Directory / path enumeration (gobuster/ffuf/dirsearch-style).

⚠️ THIS IS ACTIVE RECONNAISSANCE, unlike every other module in this tool.
It sends real HTTP requests directly to the live target, guessing paths
from a wordlist to discover hidden admin panels, config files, backups,
API endpoints, etc. This is fundamentally different from the passive
modules (subdomains/shodan/emails), which only query public third-party
records and never touch the target itself.

Only run this against a target you own or have explicit, documented
authorization to test (e.g. a signed pentest/bug-bounty scope). The CLI
and web GUI both require an explicit confirmation step before this module
runs — this module itself does not enforce that, so any other caller
integrating it directly is responsible for its own authorization gate.

Wraps the `ffuf` binary (https://github.com/ffuf/ffuf), which must be
installed separately and available on PATH:
  https://github.com/ffuf/ffuf#installation
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile

BINARY = "ffuf"
DEFAULT_WORDLIST = os.path.join(os.path.dirname(__file__), "..", "data", "common_paths.txt")
DEFAULT_MATCH_CODES = "200,204,301,302,307,401,403"


def is_installed() -> bool:
    return shutil.which(BINARY) is not None


def install_hint() -> str:
    return (
        "ffuf not found on PATH. Install: see "
        "https://github.com/ffuf/ffuf#installation "
        "(e.g. `go install github.com/ffuf/ffuf/v2@latest`, or download a "
        "release binary from https://github.com/ffuf/ffuf/releases)"
    )


def run(
    target_url: str,
    wordlist: str | None = None,
    match_codes: str = DEFAULT_MATCH_CODES,
    valid_only: bool = False,
    rate: int = 20,
    threads: int = 20,
    timeout: int = 120,
) -> dict:
    """
    Fuzz `target_url` for hidden paths using ffuf.

    target_url: base URL, e.g. "https://example.com" (no trailing FUZZ).
    wordlist: path to a wordlist file; defaults to the small bundled list.
    valid_only: if True, only return paths that responded 200/204 (an
    actual accessible page) — filters out 301/302/307/401/403, which just
    mean "something's there but you can't see/access it directly" rather
    than a confirmed, viewable path.
    rate: max requests/sec (kept conservative by default — this hits a
    real server, be a good citizen even on your own infrastructure).

    Returns {"target", "wordlist_used", "results": [...], "installed", "errors"}.
    """
    if valid_only:
        match_codes = "200,204"
    if not is_installed():
        return {
            "target": target_url,
            "wordlist_used": None,
            "results": [],
            "installed": False,
            "errors": [install_hint()],
        }

    wl = wordlist or DEFAULT_WORDLIST
    if not os.path.exists(wl):
        return {
            "target": target_url,
            "wordlist_used": wl,
            "results": [],
            "installed": True,
            "errors": [f"Wordlist not found: {wl}"],
        }

    target = target_url.rstrip("/") + "/FUZZ"

    with tempfile.TemporaryDirectory() as tmp:
        out_path = os.path.join(tmp, "ffuf_out.json")
        cmd = [
            BINARY,
            "-u", target,
            "-w", wl,
            "-mc", match_codes,
            "-of", "json",
            "-o", out_path,
            "-rate", str(rate),
            "-t", str(threads),
            "-s",  # silent stdout, we read the JSON file instead
        ]
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            return {
                "target": target_url,
                "wordlist_used": wl,
                "results": [],
                "installed": True,
                "errors": [f"ffuf timed out after {timeout}s"],
            }
        except Exception as e:
            return {
                "target": target_url,
                "wordlist_used": wl,
                "results": [],
                "installed": True,
                "errors": [f"ffuf failed to run: {e}"],
            }

        results = []
        errors = []
        if os.path.exists(out_path):
            try:
                with open(out_path) as f:
                    data = json.load(f)
                for r in data.get("results", []):
                    results.append(
                        {
                            "path": r.get("input", {}).get("FUZZ"),
                            "url": r.get("url"),
                            "status": r.get("status"),
                            "length": r.get("length"),
                            "words": r.get("words"),
                            "redirect_location": r.get("redirectlocation") or None,
                        }
                    )
            except (json.JSONDecodeError, OSError) as e:
                errors.append(f"Could not parse ffuf output: {e}")
        else:
            stderr_tail = (proc.stderr or "").strip()[:500]
            errors.append(stderr_tail or "ffuf produced no output file.")

        results.sort(key=lambda r: (r["status"] or 999, r["path"] or ""))

        return {
            "target": target_url,
            "wordlist_used": wl,
            "results": results,
            "installed": True,
            "errors": errors,
        }
