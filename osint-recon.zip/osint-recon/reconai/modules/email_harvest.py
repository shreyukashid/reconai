"""
Email pattern harvesting (theHarvester-style).

Two data sources, both passive:
  1. Hunter.io API (optional, requires key) — returns real known emails and
     the organization's dominant email naming pattern.
  2. Local pattern generator — if you supply known employee names (e.g. from
     LinkedIn OSINT you've already done manually), this generates the likely
     email addresses using common corporate naming conventions.

This module does NOT scrape search engines or social media directly (that
tends to violate ToS and is fragile); wire in an authorized data source
(Hunter.io, Clearbit, internal HR export, etc.) via `known_names` or the
Hunter.io integration.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import requests

HUNTER_URL = "https://api.hunter.io/v2/domain-search"

PATTERNS = [
    "{first}.{last}@{domain}",
    "{first}{last}@{domain}",
    "{f}{last}@{domain}",
    "{first}@{domain}",
    "{first}_{last}@{domain}",
    "{f}.{last}@{domain}",
]


@dataclass
class EmailResult:
    domain: str
    confirmed_emails: list[dict] = field(default_factory=list)  # from Hunter.io
    likely_pattern: str | None = None
    generated_candidates: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "domain": self.domain,
            "confirmed_emails": self.confirmed_emails,
            "likely_pattern": self.likely_pattern,
            "generated_candidates": sorted(set(self.generated_candidates)),
            "errors": self.errors,
        }


def _query_hunter(domain: str, api_key: str) -> tuple[list[dict], str | None]:
    resp = requests.get(
        HUNTER_URL, params={"domain": domain, "api_key": api_key}, timeout=20
    )
    resp.raise_for_status()
    data = resp.json().get("data", {})
    emails = [
        {
            "value": e.get("value"),
            "type": e.get("type"),
            "first_name": e.get("first_name"),
            "last_name": e.get("last_name"),
            "position": e.get("position"),
            "confidence": e.get("confidence"),
        }
        for e in data.get("emails", [])
    ]
    pattern = data.get("pattern")
    return emails, pattern


def _generate_candidates(names: list[str], domain: str, pattern: str | None) -> list[str]:
    candidates = []
    patterns_to_use = [pattern] if pattern else PATTERNS
    for full_name in names:
        parts = full_name.strip().lower().split()
        if len(parts) < 2:
            continue
        first, last = parts[0], parts[-1]
        f = first[0]
        for p in patterns_to_use:
            if not p:
                continue
            try:
                candidates.append(
                    p.format(first=first, last=last, f=f, domain=domain)
                )
            except (KeyError, IndexError):
                continue
    return candidates


def run(
    domain: str,
    hunter_api_key: str | None = None,
    known_names: list[str] | None = None,
) -> dict:
    """
    Harvest / generate likely employee emails for `domain`.

    known_names: optional list of "First Last" strings from OSINT you've
    already gathered (e.g. LinkedIn), used to generate likely addresses
    when Hunter.io data isn't available or as a supplement.
    """
    result = EmailResult(domain=domain)

    if hunter_api_key:
        try:
            emails, pattern = _query_hunter(domain, hunter_api_key)
            result.confirmed_emails = emails
            result.likely_pattern = pattern
        except requests.RequestException as e:
            result.errors.append(f"Hunter.io lookup failed: {e}")
    else:
        result.errors.append("No HUNTER_API_KEY configured; skipping confirmed lookup.")

    if known_names:
        result.generated_candidates = _generate_candidates(
            known_names, domain, result.likely_pattern
        )

    return result.to_dict()
