"""
Passive subdomain enumeration.

Sources:
  - crt.sh: queries public Certificate Transparency logs for any cert
    issued containing the target domain. This is the same passive
    technique Amass uses as one of its data sources.
  - DNS resolution: confirms which discovered names currently resolve,
    and classifies dead vs. live hosts.

No active brute forcing, no zone transfers, no port scanning.
"""

from __future__ import annotations

import concurrent.futures
import re
import time
from dataclasses import dataclass, field

import dns.resolver
import requests

CRT_SH_URL = "https://crt.sh/"
USER_AGENT = "ReconAI/1.0 (passive OSINT tool)"


@dataclass
class SubdomainResult:
    domain: str
    subdomains: list[str] = field(default_factory=list)
    live_hosts: dict[str, list[str]] = field(default_factory=dict)  # name -> [ips]
    dead_hosts: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "domain": self.domain,
            "subdomain_count": len(self.subdomains),
            "subdomains": sorted(self.subdomains),
            "live_hosts": self.live_hosts,
            "dead_hosts": sorted(self.dead_hosts),
            "errors": self.errors,
        }


def _query_crtsh(domain: str, retries: int = 3) -> set[str]:
    """Query crt.sh's JSON API for certificates matching *.domain."""
    names: set[str] = set()
    params = {"q": f"%.{domain}", "output": "json"}

    for attempt in range(retries):
        try:
            resp = requests.get(
                CRT_SH_URL,
                params=params,
                headers={"User-Agent": USER_AGENT},
                timeout=30,
            )
            if resp.status_code == 200 and resp.text.strip():
                data = resp.json()
                for entry in data:
                    name_value = entry.get("name_value", "")
                    for name in name_value.split("\n"):
                        name = name.strip().lower().lstrip("*.")
                        if name and domain in name and _is_valid_hostname(name):
                            names.add(name)
                return names
        except (requests.RequestException, ValueError):
            time.sleep(2 * (attempt + 1))
            continue
    return names


def _is_valid_hostname(name: str) -> bool:
    pattern = r"^[a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?)+$"
    return bool(re.match(pattern, name))


def _resolve(name: str) -> tuple[str, list[str] | None]:
    """Resolve a hostname to its A-record IPs. Returns (name, ips|None)."""
    try:
        resolver = dns.resolver.Resolver()
        resolver.timeout = 3
        resolver.lifetime = 3
        answers = resolver.resolve(name, "A")
        return name, [str(rdata) for rdata in answers]
    except Exception:
        return name, None


def resolve_many(
    names: list[str], max_workers: int = 20
) -> tuple[dict[str, list[str]], list[str]]:
    """Resolve a list of hostnames concurrently. Returns (live_hosts, dead_hosts)."""
    live_hosts: dict[str, list[str]] = {}
    dead_hosts: list[str] = []
    if not names:
        return live_hosts, dead_hosts

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as pool:
        for name, ips in pool.map(_resolve, names):
            if ips:
                live_hosts[name] = ips
            else:
                dead_hosts.append(name)
    return live_hosts, dead_hosts


def run(domain: str, resolve: bool = True, max_workers: int = 20) -> dict:
    """
    Run passive subdomain enumeration against `domain` using crt.sh only.

    Returns a dict (see SubdomainResult.to_dict).
    """
    result = SubdomainResult(domain=domain)

    found = _query_crtsh(domain)
    if not found:
        result.errors.append(
            "No results from crt.sh (rate-limited, no certs found, or network issue)."
        )
    result.subdomains = sorted(found | {domain})

    if resolve and result.subdomains:
        result.live_hosts, result.dead_hosts = resolve_many(
            result.subdomains, max_workers
        )

    return result.to_dict()
