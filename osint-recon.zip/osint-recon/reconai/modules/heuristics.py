"""
Rule-based findings — work with NO API key, so every report has useful
risk output even when the AI step is skipped or fails. The AI layer then
adds correlation and prioritisation on top.
"""

from __future__ import annotations

import re

RISKY_PORTS = {
    21: "FTP", 22: "SSH", 23: "Telnet", 445: "SMB", 1433: "MSSQL", 3306: "MySQL",
    3389: "RDP", 5432: "PostgreSQL", 5900: "VNC", 6379: "Redis", 9200: "Elasticsearch",
    11211: "Memcached", 27017: "MongoDB", 2375: "Docker API",
}
SENSITIVE_NAMES = re.compile(
    r"(^|[.-])(dev|stage|staging|uat|test|qa|demo|admin|vpn|jenkins|gitlab|grafana|kibana|"
    r"jira|internal|intranet|sso|identity|helpdesk|backup|old|beta|sandbox|mcp|gw|api)([.-]|\d|$)", re.I)
CDN_ORGS = ("cloudflare", "akamai", "fastly", "amazon cloudfront")


def _f(sev, finding, evidence, rec):
    return {"severity": sev, "finding": finding, "evidence": evidence, "recommendation": rec, "source": "rules"}


def run(data: dict) -> list[dict]:
    out: list[dict] = []
    subs = data.get("subdomains") or {}
    live = subs.get("live_hosts", {})

    names = [n for n in live if SENSITIVE_NAMES.search(n.split(".", 1)[0] + ".")]
    if names:
        out.append(_f("medium", f"{len(names)} live hosts with non-production / sensitive-sounding names",
                      ", ".join(sorted(names)[:12]),
                      "Confirm each should be internet-reachable; put dev/stage/admin behind SSO or VPN."))

    sh = data.get("shodan") or {}
    ip_ports: dict[str, set] = {}
    ip_vulns: dict[str, set] = {}
    for h in sh.get("hosts", []):
        ports = h.get("ports") or ([h["port"]] if h.get("port") else [])
        ip_ports.setdefault(h.get("ip"), set()).update(ports)
        ip_vulns.setdefault(h.get("ip"), set()).update(h.get("vulns") or [])
        org = (h.get("org") or "").lower()
        h["_cdn"] = any(c in org for c in CDN_ORGS)
    for ip, vs in ip_vulns.items():
        if vs:
            out.append(_f("high", f"Known CVEs tagged on {ip}", ", ".join(sorted(vs)[:10]),
                          "Verify the product/version actually matches, then patch or restrict exposure."))
    for ip, ports in ip_ports.items():
        hit = {p: RISKY_PORTS[p] for p in ports if p in RISKY_PORTS}
        if hit:
            out.append(_f("high" if set(hit) & {3389, 3306, 5432, 6379, 9200, 27017, 445, 2375, 23} else "medium",
                          f"Management/database service exposed on {ip}",
                          ", ".join(f"{p}/{n}" for p, n in sorted(hit.items())),
                          "Restrict to VPN/allow-listed IPs; databases and RDP should never be public."))

    for r in (data.get("httpx") or {}).get("results", []):
        d = r.get("tls_days_left")
        if d is not None and d < 0:
            out.append(_f("high", f"Expired TLS certificate on {r['host']}", f"expired {-d} days ago", "Renew the certificate."))
        elif d is not None and d < 14:
            out.append(_f("medium", f"TLS certificate expiring soon on {r['host']}", f"{d} days left", "Renew / check auto-renewal."))
        if r.get("status") in (200, 401) and re.search(r"(login|sign in|admin|jenkins|grafana|kibana|dashboard)", r.get("title") or "", re.I):
            out.append(_f("medium", f"Login/admin interface reachable: {r['host']}", f"title: {r['title']}", "Ensure MFA/SSO and rate-limiting; consider IP restriction."))
        if r.get("server") and re.search(r"/\d", r["server"]):
            out.append(_f("low", f"Server version disclosed on {r['host']}", r["server"], "Suppress version banners."))
    miss = [r for r in (data.get("httpx") or {}).get("results", []) if r.get("security_headers_missing")]
    if len(miss) >= 3:
        out.append(_f("low", f"{len(miss)} hosts missing common security headers (HSTS/CSP/XFO/XCTO)",
                      ", ".join(r["host"] for r in miss[:8]), "Set baseline security headers at the edge/CDN."))

    ty = data.get("typosquat") or {}
    reg = ty.get("registered", [])
    mx = [r for r in reg if r.get("mx")]
    if mx:
        out.append(_f("high", f"{len(mx)} lookalike domains are registered AND have mail (MX) records",
                      ", ".join(r["domain"] for r in mx[:10]),
                      "Likely phishing infrastructure: review, report/takedown, add to mail-filter blocklists."))
    elif reg:
        out.append(_f("medium", f"{len(reg)} lookalike domains registered", ", ".join(r["domain"] for r in reg[:10]),
                      "Review for brand abuse; consider defensive registration."))

    ps = data.get("port_scan") or {}
    for ip, ports in (ps.get("by_ip") or {}).items():
        hit = {p_: RISKY_PORTS[p_] for p_ in ports if p_ in RISKY_PORTS}
        if hit:
            out.append(_f("high" if set(hit) & {3389, 3306, 5432, 6379, 9200, 27017, 445, 2375, 23} else "medium",
                          f"Port scan confirms management/database service reachable on {ip}",
                          ", ".join(f"{p_}/{n}" for p_, n in sorted(hit.items())),
                          "Restrict to VPN/allow-listed IPs; this was independently confirmed by direct connection, not just third-party data."))
    for r in ps.get("open_ports", []):
        if r.get("banner") and re.search(r"(ftp|telnet|smtp|pop3|imap)", r.get("banner", ""), re.I):
            out.append(_f("low", f"Service banner grabbed on {r['ip']}:{r['port']}", r["banner"][:150],
                          "Banners can disclose software/version; consider suppressing."))

    fs = data.get("file_search") or {}
    sens = [f for f in fs.get("files", []) if f.get("sensitive")]
    if sens:
        out.append(_f("high", f"{len(sens)} publicly indexed backup/config-looking files (.sql/.env/.bak/...)",
                      ", ".join(f["url"] for f in sens[:8]),
                      "Review each; take down or restrict access, rotate any credentials found inside."))
    docs = [f for f in fs.get("files", []) if not f.get("sensitive")]
    if docs:
        out.append(_f("low", f"{len(docs)} publicly indexed documents (PDF/Office/etc.)",
                      ", ".join(f["url"] for f in docs[:8]),
                      "Check metadata (authors, software, usernames) for info leakage before it's a concern."))

    gh = (data.get("github") or {}).get("hits", [])
    if gh:
        out.append(_f("high", f"{len(gh)} public GitHub files mention the domain next to secret-like keywords",
                      "; ".join(f"{h['repo']}/{h['path']}" for h in gh[:6]),
                      "Manually review each hit; rotate any real credential found and request removal."))

    n_dead = len(subs.get("dead_hosts", []))
    if n_dead >= 10:
        out.append(_f("low", f"{n_dead} certificate/passive-source hostnames have no A record",
                      "Possible stale DNS or internal names leaked via CT logs",
                      "Check for dangling CNAMEs (subdomain takeover) and remove stale records."))
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    return sorted(out, key=lambda f: order[f["severity"]])
