"""
Shodan-backed reconnaissance.

Two modes, chosen automatically based on what's configured:

  1. InternetDB (default, free, no signup/API key required) — a per-IP
     lookup at https://internetdb.shodan.io/{ip} that returns open ports,
     hostnames, CPEs, tags, and known CVEs. Static weekly snapshot, no
     banners, no domain-wide search — but zero cost and zero setup.
     Free for non-commercial use per Shodan's terms.

  2. Full Shodan API (optional, requires SHODAN_API_KEY + paid credits) —
     domain-wide search plus raw banners. Used automatically if a key is
     present; falls back to InternetDB otherwise.

This module never scans targets itself — it only queries Shodan's own
already-collected data.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import requests

try:
    import shodan
except ImportError:  # pragma: no cover - shodan lib is optional for InternetDB-only use
    shodan = None

INTERNETDB_URL = "https://internetdb.shodan.io/{ip}"


@dataclass
class ShodanResult:
    query: str
    source: str = "internetdb"
    hosts: list[dict] = field(default_factory=list)
    total_results: int = 0
    errors: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "query": self.query,
            "source": self.source,
            "total_results": self.total_results,
            "hosts": self.hosts,
            "errors": self.errors,
        }


def _summarize_host(match: dict) -> dict:
    return {
        "ip": match.get("ip_str"),
        "port": match.get("port"),
        "org": match.get("org"),
        "hostnames": match.get("hostnames", []),
        "product": match.get("product"),
        "version": match.get("version"),
        "transport": match.get("transport"),
        "location": {
            "country": match.get("location", {}).get("country_name"),
            "city": match.get("location", {}).get("city"),
        },
        "vulns": sorted(match.get("vulns", [])) if match.get("vulns") else [],
        "banner_excerpt": (match.get("data") or "")[:300],
        "timestamp": match.get("timestamp"),
    }


def _internetdb_lookup(ip: str) -> dict | None:
    """Free, unauthenticated per-IP lookup. Returns None if no record exists."""
    try:
        resp = requests.get(INTERNETDB_URL.format(ip=ip), timeout=10)
        if resp.status_code == 404:
            return None  # no Shodan record for this IP - not an error
        resp.raise_for_status()
        data = resp.json()
        return {
            "ip": data.get("ip"),
            "ports": sorted(data.get("ports", [])),
            "hostnames": data.get("hostnames", []),
            "cpes": data.get("cpes", []),
            "tags": data.get("tags", []),
            "vulns": sorted(data.get("vulns", [])),
        }
    except requests.RequestException:
        return None


def _run_internetdb(target: str, ip_list: list[str]) -> dict:
    result = ShodanResult(query=target, source="internetdb")
    if not ip_list:
        result.errors.append(
            "No resolved IPs to look up (run subdomain enumeration first)."
        )
        return result.to_dict()

    for ip in ip_list:
        record = _internetdb_lookup(ip)
        if record:
            result.hosts.append(record)
    result.total_results = len(result.hosts)
    if not result.hosts:
        result.errors.append(
            "No InternetDB records found for the given IPs (not indexed, or no open ports seen)."
        )
    return result.to_dict()


def _run_full_api(target: str, api_key: str, ip_list: list[str] | None, limit: int) -> dict:
    api = shodan.Shodan(api_key)
    result = ShodanResult(query=f"hostname:{target}", source="shodan_api")

    try:
        search = api.search(f"hostname:{target}", limit=limit)
        result.total_results = search.get("total", 0)
        result.hosts.extend(_summarize_host(m) for m in search.get("matches", []))
    except shodan.APIError as e:
        result.errors.append(f"Shodan search failed: {e}")

    if ip_list:
        seen_ips = {h["ip"] for h in result.hosts}
        for ip in ip_list:
            if ip in seen_ips:
                continue
            try:
                host = api.host(ip)
                for banner in host.get("data", []):
                    result.hosts.append(_summarize_host(banner))
                seen_ips.add(ip)
            except shodan.APIError:
                continue  # not indexed, or lookup failed - not fatal

    return result.to_dict()


def run(
    target: str,
    api_key: str | None = None,
    ip_list: list[str] | None = None,
    limit: int = 100,
) -> dict:
    """
    Look up exposed-service info for `target`.

    If `api_key` is set and the shodan lib is installed, uses the full paid
    Shodan API (domain search + banners). Otherwise falls back to the free,
    unauthenticated InternetDB per-IP lookup using `ip_list`.
    """
    if api_key and shodan is not None:
        return _run_full_api(target, api_key, ip_list, limit)
    return _run_internetdb(target, ip_list or [])
