"""ASN / network-owner enrichment for discovered IPs via RDAP (ipwhois).
Passive: queries public RDAP registries, never touches the target."""

from __future__ import annotations

import concurrent.futures

try:
    from ipwhois import IPWhois
except ImportError:  # pragma: no cover
    IPWhois = None


def _lookup(ip: str) -> dict:
    try:
        r = IPWhois(ip).lookup_rdap(depth=0)
        return {
            "ip": ip,
            "asn": r.get("asn"),
            "asn_description": r.get("asn_description"),
            "cidr": r.get("asn_cidr"),
            "country": r.get("asn_country_code"),
            "network_name": (r.get("network") or {}).get("name"),
        }
    except Exception as e:
        return {"ip": ip, "error": str(e)[:120]}


def run(ips: list[str], max_ips: int = 100) -> dict:
    if IPWhois is None:
        return {"results": [], "by_asn": {}, "errors": ["ipwhois not installed (pip install ipwhois)."]}
    ips = sorted(set(ips))[:max_ips]
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        rows = list(pool.map(_lookup, ips))
    ok = [r for r in rows if "error" not in r]
    by_asn: dict[str, dict] = {}
    for r in ok:
        key = f"AS{r['asn']}" if r.get("asn") else "unknown"
        e = by_asn.setdefault(key, {"description": r.get("asn_description"), "country": r.get("country"), "ips": []})
        e["ips"].append(r["ip"])
    errors = []
    if rows and not ok:
        errors.append(f"All {len(rows)} RDAP lookups failed (network blocked?): {rows[0].get('error')}")
    return {"results": ok, "by_asn": by_asn, "failed": len(rows) - len(ok), "errors": errors}
