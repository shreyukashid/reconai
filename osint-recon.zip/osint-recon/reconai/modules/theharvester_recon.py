"""
theHarvester integration.

Harvests emails and hosts from public, free sources (certificate
transparency, threat-intel feeds, search engines) that don't require API
keys: crt.sh, OTX, ThreatMiner, urlscan, RapidDNS, DuckDuckGo, Anubis, Bing.

Not bundled — must be installed separately and available on PATH:
  pip install theHarvester
  (or clone https://github.com/laramies/theHarvester)

This module never passes theHarvester's active-recon flags (e.g. DNS
brute-forcing / -c, port scanning / -p, screenshots / -s) — passive
sources only.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile

BINARY_CANDIDATES = ["theHarvester", "theharvester"]
DEFAULT_SOURCES = "crtsh,otx,threatminer,urlscan,rapiddns,duckduckgo,anubis,bing"


def _find_binary() -> str | None:
    for name in BINARY_CANDIDATES:
        path = shutil.which(name)
        if path:
            return name
    return None


def is_installed() -> bool:
    return _find_binary() is not None


def install_hint() -> str:
    return (
        "theHarvester not found on PATH. Install: pip install theHarvester "
        "(or see https://github.com/laramies/theHarvester)"
    )


def run(domain: str, sources: str = DEFAULT_SOURCES, timeout: int = 180) -> dict:
    """
    Run theHarvester in passive mode against `domain` using free sources.

    Returns {"domain", "emails": [...], "hosts": [...], "installed": bool, "errors": [...]}
    """
    binary = _find_binary()
    if not binary:
        return {
            "domain": domain,
            "emails": [],
            "hosts": [],
            "installed": False,
            "errors": [install_hint()],
        }

    with tempfile.TemporaryDirectory() as tmp:
        out_prefix = os.path.join(tmp, "harvest")
        try:
            proc = subprocess.run(
                [binary, "-d", domain, "-b", sources, "-f", out_prefix],
                capture_output=True,
                text=True,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired:
            return {
                "domain": domain,
                "emails": [],
                "hosts": [],
                "installed": True,
                "errors": [f"theHarvester timed out after {timeout}s"],
            }
        except Exception as e:
            return {
                "domain": domain,
                "emails": [],
                "hosts": [],
                "installed": True,
                "errors": [f"theHarvester failed to run: {e}"],
            }

        json_path = out_prefix + ".json"
        emails: list[str] = []
        hosts: list[str] = []
        errors: list[str] = []

        if os.path.exists(json_path):
            try:
                with open(json_path) as f:
                    data = json.load(f)
                emails = sorted(set(data.get("emails") or []))
                hosts = sorted(set(data.get("hosts") or []))
            except (json.JSONDecodeError, OSError) as e:
                errors.append(f"Could not parse theHarvester output: {e}")
        else:
            stderr_tail = (proc.stderr or "").strip()[:500]
            errors.append(stderr_tail or "theHarvester produced no output file (no results?).")

        return {
            "domain": domain,
            "emails": emails,
            "hosts": hosts,
            "installed": True,
            "errors": errors,
        }
