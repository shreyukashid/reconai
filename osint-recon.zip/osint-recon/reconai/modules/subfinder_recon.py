"""
subfinder integration (ProjectDiscovery, Go binary).

Passive subdomain enumeration that aggregates many public sources beyond
just crt.sh (depending on which optional API keys subfinder itself has
configured in its own provider-config.yaml — works with zero keys too,
just fewer sources).

Not bundled — must be installed separately and available on PATH:
  https://github.com/projectdiscovery/subfinder#install

  go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest

This module only shells out to the binary in its default passive mode
(no -active flag is ever passed).
"""

from __future__ import annotations

import shutil
import subprocess

BINARY = "subfinder"


def is_installed() -> bool:
    return shutil.which(BINARY) is not None


def install_hint() -> str:
    return (
        "subfinder not found on PATH. Install: "
        "go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest "
        "(or see https://github.com/projectdiscovery/subfinder#install)"
    )


def run(domain: str, timeout: int = 120) -> dict:
    """
    Run subfinder in passive mode against `domain`.

    Returns {"domain", "subdomains": [...], "installed": bool, "errors": [...]}
    """
    if not is_installed():
        return {
            "domain": domain,
            "subdomains": [],
            "installed": False,
            "errors": [install_hint()],
        }

    try:
        proc = subprocess.run(
            [BINARY, "-d", domain, "-silent"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return {
            "domain": domain,
            "subdomains": [],
            "installed": True,
            "errors": [f"subfinder timed out after {timeout}s"],
        }
    except Exception as e:
        return {
            "domain": domain,
            "subdomains": [],
            "installed": True,
            "errors": [f"subfinder failed to run: {e}"],
        }

    subdomains = {
        line.strip().lower() for line in proc.stdout.splitlines() if line.strip()
    }
    errors = []
    if not subdomains and proc.stderr.strip():
        errors.append(proc.stderr.strip()[:500])

    return {
        "domain": domain,
        "subdomains": sorted(subdomains),
        "installed": True,
        "errors": errors,
    }
