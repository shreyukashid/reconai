"""Typosquat / lookalike-domain detection (dnstwist permutation engine +
our own DNS resolution). Passive: only DNS lookups of *candidate* domains."""

from __future__ import annotations

import concurrent.futures

import dns.resolver

try:
    import dnstwist
except ImportError:  # pragma: no cover
    dnstwist = None

# homoglyph alone yields ~4,800 candidates -> opt-in only
DEFAULT_FUZZERS = [
    "addition", "bitsquatting", "hyphenation", "insertion", "omission",
    "repetition", "replacement", "subdomain", "transposition", "vowel-swap",
    "tld-swap", "plural", "various",
]


def _generate(domain: str, include_homoglyph: bool) -> list[dict]:
    fuzzers = list(DEFAULT_FUZZERS) + (["homoglyph", "cyrillic"] if include_homoglyph else [])
    fz = dnstwist.Fuzzer(domain)
    try:
        fz.generate(fuzzers=fuzzers)
    except TypeError:  # older dnstwist: no fuzzers kwarg
        fz.generate()
    out = []
    for d in fz.domains:
        if d.get("domain") == domain or d.get("fuzzer") == "*original":
            continue
        if not include_homoglyph and d.get("fuzzer") in ("homoglyph", "cyrillic"):
            continue
        out.append({"domain": d["domain"], "fuzzer": d["fuzzer"]})
    return out


def _resolve(item: dict) -> dict | None:
    r = dns.resolver.Resolver()
    r.timeout = r.lifetime = 3
    rec = {"domain": item["domain"], "fuzzer": item["fuzzer"], "a": [], "mx": []}
    try:
        rec["a"] = [str(x) for x in r.resolve(item["domain"], "A")]
    except Exception:
        pass
    try:
        rec["mx"] = [str(x.exchange).rstrip(".") for x in r.resolve(item["domain"], "MX")]
    except Exception:
        pass
    return rec if (rec["a"] or rec["mx"]) else None


def run(domain: str, include_homoglyph: bool = False, max_candidates: int = 2500, workers: int = 40) -> dict:
    if dnstwist is None:
        return {"domain": domain, "registered": [], "candidates": 0,
                "errors": ["dnstwist not installed (pip install dnstwist)."]}
    try:
        cands = _generate(domain, include_homoglyph)
    except Exception as e:
        return {"domain": domain, "registered": [], "candidates": 0, "errors": [f"dnstwist failed: {e}"]}
    total = len(cands)
    cands = cands[:max_candidates]
    registered = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        for rec in pool.map(_resolve, cands):
            if rec:
                registered.append(rec)
    # MX present = can receive/send mail = higher phishing potential
    registered.sort(key=lambda r: (not r["mx"], r["domain"]))
    errors = []
    if total > max_candidates:
        errors.append(f"Checked {max_candidates} of {total} candidates (cap).")
    return {
        "domain": domain,
        "candidates": total,
        "checked": len(cands),
        "homoglyph_included": include_homoglyph,
        "registered": registered,
        "errors": errors,
    }
