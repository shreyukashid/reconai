from rich.console import Console

console = Console()


def info(msg: str) -> None:
    console.print(f"[bold cyan][*][/bold cyan] {msg}")


def success(msg: str) -> None:
    console.print(f"[bold green][+][/bold green] {msg}")


def warn(msg: str) -> None:
    console.print(f"[bold yellow][!][/bold yellow] {msg}")


def error(msg: str) -> None:
    console.print(f"[bold red][x][/bold red] {msg}")
