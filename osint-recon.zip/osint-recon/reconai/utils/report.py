"""Report rendering: JSON dump or a styled standalone HTML report."""

from __future__ import annotations

import json
from datetime import datetime, timezone

from jinja2 import Template

HTML_TEMPLATE = Template("""
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>ReconAI Report — {{ target }}</title>
<style>
  :root {
    --bg: #0b0f14; --panel: #131a22; --border: #223040; --text: #e6edf3;
    --muted: #8b98a5; --accent: #4fb3ff; --critical: #ff4d4f; --high: #ff9d4d;
    --medium: #ffd24d; --low: #7ee787;
  }
  body { background: var(--bg); color: var(--text); font-family: -apple-system, Segoe UI, Roboto, sans-serif; margin: 0; padding: 2rem; line-height: 1.55; }
  .wrap { max-width: 960px; margin: 0 auto; }
  h1 { font-size: 1.6rem; margin-bottom: 0.2rem; }
  .meta { color: var(--muted); font-size: 0.9rem; margin-bottom: 2rem; }
  .card { background: var(--panel); border: 1px solid var(--border); border-radius: 10px; padding: 1.25rem 1.5rem; margin-bottom: 1.5rem; }
  .card h2 { margin-top: 0; font-size: 1.1rem; color: var(--accent); }
  .finding { border-left: 3px solid var(--border); padding: 0.6rem 1rem; margin-bottom: 0.75rem; border-radius: 4px; background: rgba(255,255,255,0.02); }
  .sev-critical { border-color: var(--critical); }
  .sev-high { border-color: var(--high); }
  .sev-medium { border-color: var(--medium); }
  .sev-low { border-color: var(--low); }
  .badge { display: inline-block; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.05em; padding: 0.15rem 0.5rem; border-radius: 999px; margin-right: 0.5rem; }
  .badge-critical { background: rgba(255,77,79,0.15); color: var(--critical); }
  .badge-high { background: rgba(255,157,77,0.15); color: var(--high); }
  .badge-medium { background: rgba(255,210,77,0.15); color: var(--medium); }
  .badge-low { background: rgba(126,231,135,0.15); color: var(--low); }
  table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
  th, td { text-align: left; padding: 0.4rem 0.6rem; border-bottom: 1px solid var(--border); }
  th { color: var(--muted); font-weight: 500; }
  code { color: var(--accent); }
  ul { margin: 0.3rem 0; padding-left: 1.3rem; }
  .empty { color: var(--muted); font-style: italic; }
</style>
</head>
<body>
<div class="wrap">
  <h1>ReconAI Report — {{ target }}</h1>
  <div class="meta">Generated {{ generated_at }}</div>

  {% if ai %}
  <div class="card">
    <h2>Executive Summary</h2>
    {% if ai.error %}
      <p class="empty">{{ ai.error }}</p>
    {% else %}
      {% if ai.attack_surface_score is not none %}<p><strong>Attack surface score: {{ ai.attack_surface_score }}/100</strong> — <span style="color: var(--muted);">{{ ai.score_rationale }}</span></p>{% endif %}
      <p>{{ ai.executive_summary }}</p>
    {% endif %}
  </div>

  {% if ai.risk_findings %}
  <div class="card">
    <h2>Risk Findings</h2>
    {% for f in ai.risk_findings %}
    <div class="finding sev-{{ f.severity }}">
      <span class="badge badge-{{ f.severity }}">{{ f.severity }}</span>
      <strong>{{ f.finding }}</strong>
      <div style="color: var(--muted); font-size: 0.85rem; margin-top: 0.3rem;">{{ f.evidence }}</div>
      <div style="margin-top: 0.3rem;">→ {{ f.recommendation }}</div>
    </div>
    {% endfor %}
  </div>
  {% endif %}

  {% if ai.correlations %}
  <div class="card">
    <h2>Correlations</h2>
    <ul>{% for c in ai.correlations %}<li>{{ c }}</li>{% endfor %}</ul>
  </div>
  {% endif %}

  {% if ai.next_steps %}
  <div class="card">
    <h2>Next Steps</h2>
    <ul>{% for s in ai.next_steps %}<li>{{ s }}</li>{% endfor %}</ul>
  </div>
  {% endif %}
  {% endif %}

  {% if rules %}
  <div class="card">
    <h2>Rule-based Findings ({{ rules|length }})</h2>
    {% for f in rules %}
    <div class="finding sev-{{ f.severity }}">
      <span class="badge badge-{{ f.severity }}">{{ f.severity }}</span>
      <strong>{{ f.finding }}</strong>
      <div style="color: var(--muted); font-size: 0.85rem; margin-top: 0.3rem; word-break: break-word;">{{ f.evidence }}</div>
      <div style="margin-top: 0.3rem;">→ {{ f.recommendation }}</div>
    </div>
    {% endfor %}
  </div>
  {% endif %}

  {% if subdomains %}
  <div class="card">
    <h2>Subdomains ({{ subdomains.subdomain_count }})</h2>
    {% if subdomains.sources %}
    <p style="color: var(--muted); font-size: 0.85rem;">
      Sources: {% for src, count in subdomains.sources.items() %}{{ src }} ({{ count }}){% if not loop.last %}, {% endif %}{% endfor %}
      {% if subdomains.tool_status and not subdomains.tool_status.subfinder_installed %}<span style="color: var(--muted);"> — subfinder not installed, crt.sh only</span>{% endif %}
    </p>
    {% endif %}
    <table>
      <tr><th>Host</th><th>Status</th><th>IPs</th></tr>
      {% for name, ips in subdomains.live_hosts.items() %}
      <tr><td><code>{{ name }}</code></td><td>live</td><td>{{ ips|join(', ') }}</td></tr>
      {% endfor %}
      {% for name in subdomains.dead_hosts %}
      <tr><td><code>{{ name }}</code></td><td style="color: var(--muted);">no A record</td><td>—</td></tr>
      {% endfor %}
    </table>
  </div>
  {% endif %}

  {% if httpx %}
  <div class="card">
    <h2>HTTP Probe ({{ httpx.responsive or 0 }}/{{ httpx.probed or 0 }} responsive)</h2>
    <p style="color: var(--muted); font-size: 0.85rem;">Engine: {{ httpx.engine }}</p>
    {% for e in httpx.errors %}<p class="empty">{{ e }}</p>{% endfor %}
    {% if httpx.results %}
    <table>
      <tr><th>Host</th><th>Status</th><th>Title</th><th>Server / Tech</th><th>TLS days left</th></tr>
      {% for r in httpx.results %}
      <tr>
        <td><code>{{ r.host }}</code></td><td>{{ r.status or '—' }}</td><td>{{ r.title or '—' }}</td>
        <td>{{ (([r.server] if r.server else []) + (r.tech or []))|join(', ') or '—' }}</td>
        <td>{{ r.tls_days_left if r.tls_days_left is not none else '—' }}</td>
      </tr>
      {% endfor %}
    </table>
    {% endif %}
  </div>
  {% endif %}

  {% if whois_asn %}
  <div class="card">
    <h2>Network Ownership (ASN)</h2>
    {% for e in whois_asn.errors %}<p class="empty">{{ e }}</p>{% endfor %}
    {% if whois_asn.by_asn %}
    <table>
      <tr><th>ASN</th><th>Owner</th><th>Country</th><th>IPs</th></tr>
      {% for asn, v in whois_asn.by_asn.items() %}
      <tr><td><code>{{ asn }}</code></td><td>{{ v.description or '—' }}</td><td>{{ v.country or '—' }}</td><td>{{ v.ips|join(', ') }}</td></tr>
      {% endfor %}
    </table>
    {% endif %}
  </div>
  {% endif %}

  {% if typosquat %}
  <div class="card">
    <h2>Lookalike Domains ({{ typosquat.registered|length }} registered of {{ typosquat.candidates }} candidates)</h2>
    {% for e in typosquat.errors %}<p class="empty">{{ e }}</p>{% endfor %}
    {% if typosquat.registered %}
    <table>
      <tr><th>Domain</th><th>Technique</th><th>A records</th><th>Mail (MX)</th></tr>
      {% for r in typosquat.registered %}
      <tr>
        <td><code>{{ r.domain }}</code></td><td>{{ r.fuzzer }}</td><td>{{ r.a|join(', ') or '—' }}</td>
        <td>{% if r.mx %}<span class="badge badge-high">{{ r.mx|join(', ') }}</span>{% else %}—{% endif %}</td>
      </tr>
      {% endfor %}
    </table>
    {% endif %}
  </div>
  {% endif %}

  {% if file_search %}
  <div class="card">
    <h2>Exposed Files ({{ file_search.files|length }} found, {{ file_search.sensitive_count }} sensitive-looking)</h2>
    {% for e in file_search.errors %}<p class="empty">{{ e }}</p>{% endfor %}
    {% if file_search.files %}
    <table>
      <tr><th>URL</th><th>Extension</th><th>On target?</th></tr>
      {% for f in file_search.files %}
      <tr>
        <td><a style="color: var(--accent); word-break: break-all;" href="{{ f.url }}">{{ f.url }}</a></td>
        <td>{% if f.sensitive %}<span class="badge badge-high">{{ f.extension }}</span>{% else %}{{ f.extension }}{% endif %}</td>
        <td>{{ 'yes' if f.on_target else 'third-party' }}</td>
      </tr>
      {% endfor %}
    </table>
    {% endif %}
  </div>
  {% endif %}

  {% if github %}
  <div class="card">
    <h2>GitHub Leak Search ({{ github.hits|length }} hits)</h2>
    {% for e in github.errors %}<p class="empty">{{ e }}</p>{% endfor %}
    {% if github.hits %}
    <p style="color: var(--muted); font-size: 0.85rem;">Keyword matches only — review manually; many are benign.</p>
    <table>
      <tr><th>Repo</th><th>File</th><th>Keyword</th></tr>
      {% for h in github.hits %}
      <tr><td>{{ h.repo }}</td><td><a style="color: var(--accent);" href="{{ h.url }}">{{ h.path }}</a></td><td>{{ h.keyword }}</td></tr>
      {% endfor %}
    </table>
    {% endif %}
  </div>
  {% endif %}

  {% if shodan %}
  <div class="card">
    <h2>Shodan Findings ({{ shodan.total_results }} total indexed)</h2>
    {% if shodan.hosts %}
    <table>
      <tr><th>IP</th><th>Port</th><th>Product</th><th>Org</th><th>Vulns</th></tr>
      {% for h in shodan.hosts %}
      <tr>
        <td><code>{{ h.ip }}</code></td>
        <td>{{ h.port }}</td>
        <td>{{ h.product or '—' }} {{ h.version or '' }}</td>
        <td>{{ h.org or '—' }}</td>
        <td>{% if h.vulns %}<span class="badge badge-critical">{{ h.vulns|join(', ') }}</span>{% else %}—{% endif %}</td>
      </tr>
      {% endfor %}
    </table>
    {% else %}
    <p class="empty">No hosts returned.</p>
    {% endif %}
  </div>
  {% endif %}

  {% if emails %}
  <div class="card">
    <h2>Email Intelligence</h2>
    {% if emails.tool_status and not emails.tool_status.theharvester_installed %}
    <p style="color: var(--muted); font-size: 0.85rem;">theHarvester not installed — using Hunter.io / pattern generation only.</p>
    {% endif %}
    {% if emails.likely_pattern %}<p>Detected pattern: <code>{{ emails.likely_pattern }}</code></p>{% endif %}
    {% if emails.confirmed_emails %}
    <table>
      <tr><th>Email</th><th>Name</th><th>Position</th><th>Confidence</th><th>Source</th></tr>
      {% for e in emails.confirmed_emails %}
      <tr>
        <td><code>{{ e.value }}</code></td>
        <td>{{ ((e.first_name or '') ~ ' ' ~ (e.last_name or ''))|trim or '—' }}</td>
        <td>{{ e.position or '—' }}</td>
        <td>{{ e.confidence ~ '%' if e.confidence is not none else '—' }}</td>
        <td>{{ e.source or 'Hunter.io' }}</td>
      </tr>
      {% endfor %}
    </table>
    {% endif %}
    {% if emails.generated_candidates %}
    <p style="margin-top:1rem; color: var(--muted);">Generated candidates (unverified):</p>
    <ul>{% for c in emails.generated_candidates %}<li><code>{{ c }}</code></li>{% endfor %}</ul>
    {% endif %}
  </div>
  {% endif %}

</div>
</body>
</html>
""")


def render_json(data: dict) -> str:
    return json.dumps(data, indent=2, default=str)


def render_html(data: dict) -> str:
    return HTML_TEMPLATE.render(
        target=data.get("target", "unknown"),
        generated_at=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        ai=data.get("ai_analysis"),
        subdomains=data.get("subdomains"),
        shodan=data.get("shodan"),
        emails=data.get("emails"),
        httpx=data.get("httpx"),
        whois_asn=data.get("whois_asn"),
        typosquat=data.get("typosquat"),
        github=data.get("github"),
        rules=data.get("rule_findings"),
        file_search=data.get("file_search"),
        port_scan=data.get("port_scan"),
    )


def to_json(data: dict, path: str) -> None:
    with open(path, "w") as f:
        f.write(render_json(data))


def to_html(data: dict, path: str) -> None:
    with open(path, "w") as f:
        f.write(render_html(data))
