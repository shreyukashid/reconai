"""
Launch the ReconAI local web GUI.

Usage:
    python run_gui.py

Then open http://127.0.0.1:5151 in your browser.
"""

import webbrowser
from threading import Timer

from reconai.webapp import main


def _open_browser():
    webbrowser.open("http://127.0.0.1:5151")


if __name__ == "__main__":
    Timer(1.0, _open_browser).start()
    main()
