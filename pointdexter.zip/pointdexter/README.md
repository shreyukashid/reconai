# Pointdexter

A modular OSINT reconnaissance CLI that aggregates passive intelligence from
Shodan, certificate-transparency logs (Amass-style subdomain discovery), and
employee/email harvesting patterns (theHarvester-style) — then uses Claude to
correlate findings, score risk, and generate a plain-English report.

## ⚠️ Scope & Legal Use

This tool only queries **public, passive data sources** (Shodan's existing
index, public CT logs, DNS records). It does **not** perform active scanning,
exploitation, port scanning, brute forcing, or credential attacks.

Only use this against assets you own or are explicitly authorized to assess
(e.g. via a signed pentest/bug-bounty scope). Unauthorized reconnaissance of
third-party infrastructure may violate the CFAA, the UK Computer Misuse Act,
or equivalent laws in your jurisdiction.

## Features

| Module | Source | What it does |
|---|---|---|
| `subdomains` | crt.sh (Certificate Transparency) + DNS resolution | Passive subdomain discovery, live/dead host classification |
| `shodan` | Shodan API | Exposed services, banners, vulns (CVEs Shodan tags), org/ASN info |
| `emails` | crt.sh org data + pattern generation + optional Hunter.io | Likely employee email patterns for a domain |
| `analyze` | Anthropic Claude API | Correlates all findings, flags high-risk exposures, writes an executive summary |
| `rules` | built-in heuristics | Key-less findings: risky exposed ports, CVEs, dev/stage/admin hostnames, expiring TLS, lookalikes with mail, GitHub hits. Always runs, so reports are useful even if AI fails. |
| `httpx` (opt-in, semi-active) | httpx binary, or Python fallback | One GET per live host: status, title, server, tech, TLS expiry, missing security headers |
| `whois` (opt-in) | RDAP via ipwhois | ASN / network owner per IP (spot shadow IT, cloud sprawl) |
| `typosquat` (opt-in) | dnstwist permutations + DNS | Registered lookalike domains; flags ones with MX records (phishing-capable). `--homoglyph` adds ~4,800 slow candidates |
| `github` (opt-in) | GitHub code search | Public files mentioning the domain next to password/api_key/.env etc. Needs free `GITHUB_TOKEN` |
| `filesearch` (opt-in) | DuckDuckGo dorking | Publicly indexed PDFs/Office docs/backups (`site:domain filetype:X`); flags `.sql/.env/.bak/...` as sensitive |
| `directories` ⚠️ active | ffuf | Fuzzes the live target for hidden paths (admin panels, configs, backups). Requires explicit authorization confirmation. |

## Install

```bash
cd pointdexter
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp config.example.env .env
# edit .env and add your SHODAN_API_KEY and ANTHROPIC_API_KEY
```

## Usage

### Web GUI (recommended)

```bash
python run_gui.py
```

This opens http://127.0.0.1:5151 in your browser — a form to enter a target
domain, pick which modules to run, optionally list known employee names, and
click "Run Recon". A live log streams while it runs, then you land on a
results page with a styled report and JSON/HTML download buttons. Runs
locally only; nothing is sent anywhere except the APIs each module calls
(crt.sh, Shodan/InternetDB, Hunter.io, Anthropic).

### CLI

```bash
# Full recon run against a domain you're authorized to assess
python -m pointdexter.cli run example.com --output report.html

# Same, plus all enrichment modules
python -m pointdexter.cli run example.com --all-enrichment -o report.html
python -m pointdexter.cli typosquat example.com
python -m pointdexter.cli github example.com

# Individual modules
python -m pointdexter.cli subdomains example.com
python -m pointdexter.cli shodan example.com
python -m pointdexter.cli emails example.com --company "Example Inc"

# Just AI-analyze an existing JSON results file
python -m pointdexter.cli analyze results.json
```

## Troubleshooting: "AI analysis failed ... 401 invalid x-api-key"

The AI step needs an **API key from console.anthropic.com** (separate from a
Claude.ai chat subscription, and it needs API credits). Put it in `.env` as
`ANTHROPIC_API_KEY=sk-ant-...` with no quotes or spaces, then restart the GUI.
Rule-based findings are shown regardless.

## API keys needed

- **GitHub** (optional, for leak search): https://github.com/settings/tokens (no scopes needed)
- **Shodan**: https://account.shodan.io/ (free tier works, limited results)
- **Anthropic**: https://console.anthropic.com/ (for the AI analysis layer)
- **Hunter.io** (optional, improves email harvesting): https://hunter.io/api

## Optional binaries (auto-detected, no config needed)

If installed and on your `PATH`, these are used automatically to augment
results — the tool works fine without them, just with less coverage.

**subfinder** (ProjectDiscovery) — extra passive subdomain sources beyond crt.sh:
```bash
go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
```
See https://github.com/projectdiscovery/subfinder#install for other install methods.

**theHarvester** — email harvesting from free sources (crt.sh, OTX, ThreatMiner,
urlscan, RapidDNS, DuckDuckGo, Anubis, Bing):
```bash
pip install theHarvester
```
See https://github.com/laramies/theHarvester for other install methods.

Both are run in passive-only mode — no active DNS brute-forcing, port
scanning, or crawling is ever triggered by this tool.

**ffuf** — powers the optional, explicitly-gated directory/path enumeration
module (see below). Install a release binary from
https://github.com/ffuf/ffuf/releases, or:
```bash
go install github.com/ffuf/ffuf/v2@latest
```

## ⚠️ Port scanning (active — separate from everything else)

A standalone `portscan` command / GUI card, like directory enumeration below:
direct TCP-connect attempts against ~100 common ports per target IP/hostname
(uses `nmap` for service/version detection if installed, else a pure-Python
socket scan). Gated the same way:

- **CLI**: `python -m pointdexter.cli portscan example.com --i-am-authorized`
- **GUI**: check the authorization box and type `AUTHORIZED`.

Not included in `run`/`--all-enrichment` — run it explicitly.

## ⚠️ Directory enumeration (active — separate from everything else)

Unlike every other module, `directories` sends real HTTP requests directly
to the live target, guessing paths from a wordlist to find hidden admin
panels, config files, backups, and API endpoints. This is fundamentally
different from the passive modules above, which only query third-party
public records.

**Only run this against a target you own or have explicit, documented
authorization to test.** Both front-ends require an explicit confirmation
step:

- **CLI**: requires `--i-am-authorized`, e.g.
  ```bash
  python -m pointdexter.cli directories https://example.com --i-am-authorized
  ```
- **GUI**: requires checking an authorization box *and* typing `AUTHORIZED`
  before the button becomes clickable.

A small built-in wordlist (~150 common paths) is bundled at
`pointdexter/data/common_paths.txt`; pass `--wordlist /path/to/your/list.txt`
(CLI) for a larger one (e.g. from SecLists).

## Output

Results are stored as structured JSON (`--output results.json`) or as a
styled HTML report (`--output report.html`) with a Claude-generated risk
summary at the top.

## Extending

Each module in `pointdexter/modules/` is independent and returns plain dicts/lists,
so adding a new source (e.g. SecurityTrails, Censys, GitHub dorking) just
means writing a new module with a `run(target) -> dict` function and wiring
it into `cli.py`.
