from __future__ import annotations

import json
import os

import click
from dotenv import load_dotenv

from pointdexter.modules import (
    ai_analysis,
    dir_enum,
    dnstwist_scan,
    file_search,
    github_leaks,
    port_scan,
    shodan_recon,
    subdomain_enum,
)
from pointdexter.pipeline import enumerate_subdomains, harvest_emails, run_full
from pointdexter.utils import logger
from pointdexter.utils.report import to_html, to_json

load_dotenv()


def _env(key: str) -> str | None:
    return os.environ.get(key) or None


@click.group()
def cli():
    """Pointdexter — passive OSINT recon with AI-assisted analysis.

    Only use against targets you own or are explicitly authorized to assess.
    """
    pass


@cli.command()
@click.argument("domain")
@click.option("--output", "-o", default=None, help="Write JSON results to this file.")
def subdomains(domain: str, output: str | None):
    """Passive subdomain enumeration via crt.sh (+ subfinder if installed) + DNS."""
    result = enumerate_subdomains(domain, log=logger.info)
    logger.success(
        f"Found {result['subdomain_count']} subdomains "
        f"({len(result['live_hosts'])} live, {len(result['dead_hosts'])} dead). "
        f"Sources: {result['sources']}"
    )
    if output:
        to_json(result, output)
        logger.info(f"Saved to {output}")
    else:
        click.echo(json.dumps(result, indent=2))


@cli.command()
@click.argument("domain")
@click.option("--output", "-o", default=None, help="Write JSON results to this file.")
@click.option("--limit", default=100, help="Max Shodan search results (paid API only).")
def shodan(domain: str, output: str | None, limit: int):
    """Query Shodan for exposed services. Uses free InternetDB by default,
    or the full paid API if SHODAN_API_KEY is set."""
    api_key = _env("SHODAN_API_KEY")
    sub_result = enumerate_subdomains(domain, log=logger.info)
    ip_list = sorted({ip for ips in sub_result["live_hosts"].values() for ip in ips})

    if api_key:
        logger.info(f"Querying Shodan (full API) for hostname:{domain}...")
    else:
        logger.info(f"No SHODAN_API_KEY set — using free InternetDB for {len(ip_list)} resolved IPs...")

    result = shodan_recon.run(domain, api_key=api_key, ip_list=ip_list, limit=limit)
    logger.success(f"Shodan returned {len(result['hosts'])} host records (source: {result['source']}).")
    if output:
        to_json(result, output)
        logger.info(f"Saved to {output}")
    else:
        click.echo(json.dumps(result, indent=2))


@cli.command()
@click.argument("domain")
@click.option("--company", default=None, help="Company name (currently informational).")
@click.option(
    "--known-name",
    "known_names",
    multiple=True,
    help="A known employee full name, e.g. --known-name 'Jane Doe'. Repeatable.",
)
@click.option("--output", "-o", default=None, help="Write JSON results to this file.")
def emails(domain: str, company: str | None, known_names: tuple[str], output: str | None):
    """Harvest / generate likely employee emails for a domain."""
    hunter_key = _env("HUNTER_API_KEY")
    result = harvest_emails(
        domain, hunter_key=hunter_key, known_names=list(known_names) or None, log=logger.info
    )
    logger.success(
        f"{len(result['confirmed_emails'])} confirmed, "
        f"{len(result['generated_candidates'])} generated candidates."
    )
    if output:
        to_json(result, output)
        logger.info(f"Saved to {output}")
    else:
        click.echo(json.dumps(result, indent=2))


@cli.command()
@click.argument("target_url")
@click.option(
    "--i-am-authorized",
    is_flag=True,
    required=True,
    help="Required. Confirms you own this target or have explicit written authorization to test it.",
)
@click.option("--wordlist", default=None, help="Path to a custom wordlist (defaults to bundled common paths).")
@click.option(
    "--valid-only",
    is_flag=True,
    help="Only show paths that responded 200/204 (actually accessible), hiding 301/302/401/403 noise.",
)
@click.option("--rate", default=20, help="Max requests/sec.")
@click.option("--output", "-o", default=None, help="Write JSON results to this file.")
def directories(
    target_url: str,
    i_am_authorized: bool,
    wordlist: str | None,
    valid_only: bool,
    rate: int,
    output: str | None,
):
    """[ACTIVE] Fuzz TARGET_URL for hidden paths via ffuf. Sends real requests
    to the live target — only use on something you're authorized to test."""
    logger.warn(
        "This sends live HTTP requests directly to the target. "
        "Only proceed if you own it or have explicit authorization."
    )
    logger.info(f"Fuzzing {target_url} for common paths (rate={rate}/s)...")
    result = dir_enum.run(target_url, wordlist=wordlist, valid_only=valid_only, rate=rate)
    if not result["installed"]:
        logger.error(result["errors"][0])
        return
    for e in result.get("errors", []):
        logger.warn(e)
    logger.success(f"Found {len(result['results'])} responsive paths.")
    if output:
        to_json(result, output)
        logger.info(f"Saved to {output}")
    else:
        click.echo(json.dumps(result, indent=2))


@cli.command()
@click.argument("domain")
@click.option("--homoglyph", is_flag=True, help="Include slow homoglyph permutations.")
@click.option("--output", "-o", default=None)
def typosquat(domain: str, homoglyph: bool, output: str | None):
    """Find registered lookalike domains (dnstwist permutations + DNS)."""
    result = dnstwist_scan.run(domain, include_homoglyph=homoglyph)
    for e in result.get("errors", []):
        logger.warn(e)
    logger.success(f"{len(result.get('registered', []))} registered lookalikes of {result.get('candidates', 0)} candidates.")
    if output:
        to_json(result, output)
    else:
        click.echo(json.dumps(result, indent=2))


@cli.command()
@click.argument("domain")
@click.option("--output", "-o", default=None)
def github(domain: str, output: str | None):
    """Search public GitHub code for secrets near DOMAIN (needs GITHUB_TOKEN)."""
    result = github_leaks.run(domain, _env("GITHUB_TOKEN"))
    for e in result.get("errors", []):
        logger.warn(e)
    logger.success(f"{len(result['hits'])} hits.")
    if output:
        to_json(result, output)
    else:
        click.echo(json.dumps(result, indent=2))


@cli.command()
@click.argument("domain")
@click.option("--output", "-o", default=None)
def filesearch(domain: str, output: str | None):
    """Search engines for publicly indexed files under DOMAIN (passive, no key needed)."""
    result = file_search.run(domain)
    for e in result.get("errors", []):
        logger.warn(e)
    logger.success(f"{len(result['files'])} files found ({result['sensitive_count']} sensitive-looking).")
    if output:
        to_json(result, output)
    else:
        click.echo(json.dumps(result, indent=2))


@cli.command()
@click.argument("targets", nargs=-1, required=True)
@click.option(
    "--i-am-authorized",
    is_flag=True,
    required=True,
    help="Required. Confirms you own this target or have explicit written authorization to test it.",
)
@click.option("--ports", default=None, help="Comma-separated port list (defaults to a ~100-port common list).")
@click.option("--rate", default=200, help="Approx. connection attempts/sec (python-socket engine only).")
@click.option("--output", "-o", default=None)
def portscan(targets: tuple[str], i_am_authorized: bool, ports: str | None, rate: int, output: str | None):
    """[ACTIVE] TCP-connect port scan of one or more IPs/hostnames. Sends
    real connection attempts to the live target — only use on something
    you're authorized to test."""
    logger.warn(
        "This opens real TCP connections directly to the target(s). "
        "Only proceed if you own them or have explicit authorization."
    )
    port_list = [int(p) for p in ports.split(",")] if ports else None
    logger.info(f"Scanning {len(targets)} target(s)...")
    result = port_scan.run(list(targets), ports=port_list, rate_per_sec=rate)
    for e in result.get("errors", []):
        logger.warn(e)
    logger.success(f"{len(result['open_ports'])} open ports found (engine: {result['engine']}).")
    if output:
        to_json(result, output)
    else:
        click.echo(json.dumps(result, indent=2))


@cli.command()
@click.argument("results_file")
@click.option("--output", "-o", default=None, help="Write JSON results to this file.")
def analyze(results_file: str, output: str | None):
    """Run AI analysis over an existing aggregated JSON results file."""
    api_key = _env("ANTHROPIC_API_KEY")
    with open(results_file) as f:
        data = json.load(f)
    logger.info("Sending data to Claude for correlation and risk analysis...")
    result = ai_analysis.run(data, api_key=api_key)
    if result.get("error"):
        logger.warn(result["error"])
    else:
        logger.success("AI analysis complete.")
    if output:
        to_json(result, output)
        logger.info(f"Saved to {output}")
    else:
        click.echo(json.dumps(result, indent=2))


@cli.command()
@click.argument("domain")
@click.option("--output", "-o", default="report.html", help="Output file (.html or .json).")
@click.option("--company", default=None, help="Company name for email module.")
@click.option(
    "--known-name",
    "known_names",
    multiple=True,
    help="Known employee full name for email candidate generation. Repeatable.",
)
@click.option("--skip-ai", is_flag=True, help="Skip the Claude analysis step.")
@click.option("--httpx", "do_httpx", is_flag=True, help="Probe live hosts over HTTP(S): status/title/tech/TLS (semi-active).")
@click.option("--whois", "do_whois", is_flag=True, help="ASN / network-owner lookup for discovered IPs (RDAP).")
@click.option("--typosquat", "do_typo", is_flag=True, help="Find registered lookalike domains (dnstwist).")
@click.option("--homoglyph", is_flag=True, help="Include slow homoglyph permutations (~4,800 candidates).")
@click.option("--github", "do_github", is_flag=True, help="Search public GitHub for leaks (needs GITHUB_TOKEN).")
@click.option("--filesearch", "do_filesearch", is_flag=True, help="Search engines for exposed documents (filetype dorking, passive).")
@click.option("--all-enrichment", is_flag=True, help="Enable httpx, whois, typosquat, github and filesearch.")
def run(domain: str, output: str, company: str | None, known_names: tuple[str], skip_ai: bool,
        do_httpx: bool, do_whois: bool, do_typo: bool, homoglyph: bool, do_github: bool, do_filesearch: bool,
        all_enrichment: bool):
    """Full recon pipeline: subdomains -> shodan -> emails -> enrichment -> rules + AI -> report.

    Port scanning is NOT included here (it's active) — use the separate
    `portscan` command with --i-am-authorized.
    """
    mods = {"subdomains", "shodan", "emails"}
    for flag, name in ((do_httpx, "httpx"), (do_whois, "whois"), (do_typo, "typosquat"),
                      (do_github, "github"), (do_filesearch, "filesearch")):
        if flag or all_enrichment:
            mods.add(name)
    aggregated = run_full(
        domain,
        shodan_key=_env("SHODAN_API_KEY"),
        hunter_key=_env("HUNTER_API_KEY"),
        anthropic_key=_env("ANTHROPIC_API_KEY"),
        known_names=list(known_names) or None,
        skip_ai=skip_ai,
        modules=mods,
        github_token=_env("GITHUB_TOKEN"),
        homoglyph=homoglyph,
        log=logger.info,
    )

    if output.endswith(".json"):
        to_json(aggregated, output)
    else:
        to_html(aggregated, output)
    logger.success(f"Report written to {output}")


if __name__ == "__main__":
    cli()
