"""
HTTP-level probing of discovered live hosts.

Uses ProjectDiscovery's `httpx` binary when installed (status, title, tech
stack, web server, TLS cert), and falls back to a pure-Python `requests`
probe otherwise (status, title, server, redirect target, security headers).

NOTE: this is *semi-active* — it sends one normal HTTP(S) GET per host.
It does not fuzz, crawl or guess paths.
"""

from __future__ import annotations

import concurrent.futures
import json
import re
import shutil
import subprocess
from datetime import datetime, timezone

import requests

BINARY = "httpx"
USER_AGENT = "Pointdexter/1.1 (authorized recon)"
SEC_HEADERS = [
    "strict-transport-security",
    "content-security-policy",
    "x-frame-options",
    "x-content-type-options",
]


def _is_projectdiscovery_httpx() -> bool:
    """The python `httpx` package also installs a CLI named httpx - make sure
    we found ProjectDiscovery's Go binary, not that."""
    path = shutil.which(BINARY)
    if not path:
        return False
    try:
        out = subprocess.run(
            [path, "-version"], capture_output=True, text=True, timeout=10
        )
        return "projectdiscovery" in (out.stdout + out.stderr).lower()
    except Exception:
        return False


def is_installed() -> bool:
    return _is_projectdiscovery_httpx()


def _days_until(date_str: str | None) -> int | None:
    if not date_str:
        return None
    for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%d %H:%M:%S"):
        try:
            dt = datetime.strptime(date_str, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return (dt - datetime.now(timezone.utc)).days
        except ValueError:
            continue
    return None


def _run_binary(hosts: list[str], timeout: int) -> tuple[list[dict], list[str]]:
    errors: list[str] = []
    cmd = [
        BINARY, "-silent", "-json", "-status-code", "-title", "-tech-detect",
        "-web-server", "-tls-grab", "-follow-redirects", "-timeout", "10",
        "-threads", "25",
    ]
    try:
        # hosts piped via stdin: `-l file` mode can hang in restricted networks
        proc = subprocess.run(
            cmd, input="\n".join(hosts), capture_output=True, text=True, timeout=timeout
        )
    except subprocess.TimeoutExpired:
        return [], [f"httpx timed out after {timeout}s"]
    except Exception as e:
        return [], [f"httpx failed to run: {e}"]

    results = []
    for line in proc.stdout.splitlines():
        try:
            j = json.loads(line)
        except ValueError:
            continue
        tls = j.get("tls") or {}
        not_after = tls.get("not_after")
        results.append({
            "host": j.get("input") or j.get("host"),
            "url": j.get("url"),
            "status": j.get("status_code"),
            "title": (j.get("title") or "")[:120],
            "server": j.get("webserver"),
            "tech": j.get("tech") or [],
            "tls_issuer": tls.get("issuer_cn") or (tls.get("issuer_org") or [None])[0]
            if tls else None,
            "tls_expires": not_after,
            "tls_days_left": _days_until(not_after),
            "redirect": j.get("final_url") if j.get("final_url") != j.get("url") else None,
            "security_headers_missing": [],
            "engine": "httpx",
        })
    if not results and proc.stderr.strip():
        errors.append(proc.stderr.strip()[:300])
    return results, errors


def _probe_one(host: str) -> dict | None:
    for scheme in ("https", "http"):
        url = f"{scheme}://{host}"
        try:
            r = requests.get(
                url, timeout=8, allow_redirects=True,
                headers={"User-Agent": USER_AGENT}, stream=True,
            )
            body = next(r.iter_content(65536), b"").decode("utf-8", "ignore")
            m = re.search(r"<title[^>]*>(.*?)</title>", body, re.I | re.S)
            hdrs = {k.lower(): v for k, v in r.headers.items()}
            tech = []
            if hdrs.get("x-powered-by"):
                tech.append(hdrs["x-powered-by"])
            if "wp-content" in body:
                tech.append("WordPress")
            r.close()
            return {
                "host": host,
                "url": url,
                "status": r.status_code,
                "title": re.sub(r"\s+", " ", m.group(1)).strip()[:120] if m else "",
                "server": hdrs.get("server"),
                "tech": tech,
                "tls_issuer": None,
                "tls_expires": None,
                "tls_days_left": None,
                "redirect": r.url if r.url.rstrip("/") != url.rstrip("/") else None,
                "security_headers_missing": (
                    [h for h in SEC_HEADERS if h not in hdrs] if scheme == "https" else SEC_HEADERS
                ),
                "engine": "requests",
            }
        except requests.RequestException:
            continue
    return None


def _run_python(hosts: list[str]) -> tuple[list[dict], list[str]]:
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as pool:
        for res in pool.map(_probe_one, hosts):
            if res:
                results.append(res)
    return results, []


def run(hosts: list[str], timeout: int = 300, max_hosts: int = 300) -> dict:
    hosts = sorted(set(hosts))[:max_hosts]
    if not hosts:
        return {"installed": is_installed(), "engine": None, "results": [], "errors": ["No live hosts to probe."]}
    if is_installed():
        results, errors = _run_binary(hosts, timeout)
        engine = "httpx"
    else:
        results, errors = _run_python(hosts)
        engine = "requests (httpx binary not installed — no tech-detect/TLS info)"
    return {
        "installed": is_installed(),
        "engine": engine,
        "probed": len(hosts),
        "responsive": len(results),
        "results": sorted(results, key=lambda r: r.get("host") or ""),
        "errors": errors,
    }
