"""Public GitHub code search for secrets/config referencing the target domain.
Needs a free GITHUB_TOKEN (no scopes) - code search rejects anonymous calls.
Only metadata (repo/path/url) is stored; file contents are never fetched."""

from __future__ import annotations

import time

import requests

API = "https://api.github.com/search/code"
KEYWORDS = ["password", "api_key", "secret", "token", ".env", "aws_access_key_id", "BEGIN RSA PRIVATE KEY", "jdbc:"]


def run(domain: str, token: str | None, keywords: list[str] | None = None, per_query: int = 10) -> dict:
    if not token:
        return {"domain": domain, "hits": [], "queries": 0,
                "errors": ["No GITHUB_TOKEN set — GitHub code search requires authentication (free token, no scopes)."]}
    headers = {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json",
               "User-Agent": "Pointdexter"}
    hits, errors, seen = [], [], set()
    kws = keywords or KEYWORDS
    for i, kw in enumerate(kws):
        try:
            r = requests.get(API, headers=headers, params={"q": f'"{domain}" {kw}', "per_page": per_query}, timeout=20)
        except requests.RequestException as e:
            errors.append(f"{kw}: {e}")
            continue
        if r.status_code in (401, 403) and "rate" not in r.text.lower():
            errors.append(f"GitHub rejected the token ({r.status_code}).")
            break
        if r.status_code in (403, 429):
            errors.append("GitHub rate limit hit (code search allows ~10 req/min); partial results.")
            break
        if r.status_code != 200:
            errors.append(f"{kw}: HTTP {r.status_code}")
            continue
        for it in r.json().get("items", []):
            url = it.get("html_url")
            if url in seen:
                continue
            seen.add(url)
            hits.append({"keyword": kw, "repo": it["repository"]["full_name"], "path": it["path"], "url": url,
                         "is_fork": it["repository"].get("fork", False)})
        if i < len(kws) - 1:
            time.sleep(6.5)  # stay under the code-search rate limit
    return {"domain": domain, "hits": hits, "queries": len(kws), "errors": errors}
