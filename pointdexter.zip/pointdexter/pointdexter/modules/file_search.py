"""
Exposed-document / "file search" OSINT (Metagoofil/FOCA-style, no API key).

Passive: queries a public search engine (DuckDuckGo HTML endpoint, no key
needed) for files it has already indexed under the target domain —
`site:domain filetype:pdf`, etc. Never touches the target directly;
finds documents search engines already crawled and cached.

Interesting because exposed PDFs/DOCX/XLSX often leak author names,
internal software versions, and usernames in their metadata, and because
backup/config-looking files found this way (.sql, .env, .bak) are often
legacy artifacts that were never meant to be public.
"""

from __future__ import annotations

import re
import time
from urllib.parse import unquote, urlparse

import requests

SEARCH_URL = "https://html.duckduckgo.com/html/"
USER_AGENT = "Mozilla/5.0 (Pointdexter/1.1; authorized recon; +passive search only)"

DEFAULT_EXTENSIONS = ["pdf", "docx", "doc", "xlsx", "xls", "pptx", "csv", "txt"]
SENSITIVE_EXTENSIONS = ["sql", "env", "bak", "conf", "config", "log", "zip", "key", "pem"]

# DuckDuckGo's HTML results wrap the real URL in a redirect like
# //duckduckgo.com/l/?uddg=<encoded-url>&...
_REDIRECT_RE = re.compile(r"uddg=([^&\"]+)")
_RESULT_LINK_RE = re.compile(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"', re.I)


def _extract_url(raw_href: str) -> str | None:
    m = _REDIRECT_RE.search(raw_href)
    if m:
        return unquote(m.group(1))
    if raw_href.startswith("http"):
        return raw_href
    return None


def _search_one(domain: str, ext: str, max_results: int) -> tuple[list[str], str | None]:
    query = f"site:{domain} filetype:{ext}"
    try:
        resp = requests.post(
            SEARCH_URL, data={"q": query},
            headers={"User-Agent": USER_AGENT}, timeout=15,
        )
    except requests.RequestException as e:
        return [], f"{ext}: {e}"
    if resp.status_code != 200:
        return [], f"{ext}: HTTP {resp.status_code}"
    urls = []
    for href in _RESULT_LINK_RE.findall(resp.text):
        u = _extract_url(href)
        if u:
            urls.append(u)
    return urls[:max_results], None


def run(domain: str, extensions: list[str] | None = None, include_sensitive: bool = True,
        max_results_per_ext: int = 15, delay: float = 1.2) -> dict:
    """
    Search for publicly indexed files under `domain` by extension.

    include_sensitive: also dork for backup/config-looking extensions
    (.sql, .env, .bak, ...) — these found "in the wild" are almost always
    worth a manual look, unlike a stray public PDF.
    """
    exts = list(extensions or DEFAULT_EXTENSIONS)
    if include_sensitive:
        exts += SENSITIVE_EXTENSIONS

    files: list[dict] = []
    seen: set[str] = set()
    errors: list[str] = []

    for i, ext in enumerate(exts):
        urls, err = _search_one(domain, ext, max_results_per_ext)
        if err:
            errors.append(err)
        for u in urls:
            if u in seen:
                continue
            seen.add(u)
            host = urlparse(u).netloc
            files.append({
                "url": u,
                "extension": ext,
                "host": host,
                "on_target": domain in host,
                "sensitive": ext in SENSITIVE_EXTENSIONS,
            })
        if i < len(exts) - 1:
            time.sleep(delay)  # be polite to the search engine, avoid being blocked

    files.sort(key=lambda f: (not f["sensitive"], f["extension"], f["url"]))
    return {
        "domain": domain,
        "extensions_searched": exts,
        "files": files,
        "sensitive_count": sum(1 for f in files if f["sensitive"]),
        "errors": errors,
    }
