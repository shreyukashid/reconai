"""
Local web GUI for Pointdexter.

Run with:  python run_gui.py
Then open: http://127.0.0.1:5151

This wraps the same modules/pipeline used by the CLI (`pointdexter.pipeline`)
behind a simple form + results page. Jobs run in a background thread per
request and are held in memory only (nothing persists after the process
exits) — fine for a local, single-user tool.
"""

from __future__ import annotations

import os
import threading
import traceback
import uuid

from dotenv import load_dotenv
from flask import Flask, Response, jsonify, redirect, render_template, request, url_for

from pointdexter.modules import dir_enum, httpx_probe, port_scan, subfinder_recon, theharvester_recon
from pointdexter.pipeline import run_full
from pointdexter.utils.report import render_html, render_json

load_dotenv()

app = Flask(__name__)

# In-memory job store: job_id -> {"status", "log", "data", "error", "domain"}
JOBS: dict[str, dict] = {}


def _env(key: str) -> str | None:
    return os.environ.get(key) or None


def _index_ctx(**extra) -> dict:
    return dict(
        shodan_configured=bool(_env("SHODAN_API_KEY")),
        hunter_configured=bool(_env("HUNTER_API_KEY")),
        anthropic_configured=bool(_env("ANTHROPIC_API_KEY")),
        github_configured=bool(_env("GITHUB_TOKEN")),
        subfinder_installed=subfinder_recon.is_installed(),
        theharvester_installed=theharvester_recon.is_installed(),
        ffuf_installed=dir_enum.is_installed(),
        httpx_installed=httpx_probe.is_installed(),
        nmap_installed=port_scan.is_nmap_installed(),
        **extra,
    )


@app.route("/")
def index():
    return render_template("index.html", **_index_ctx())


@app.route("/run", methods=["POST"])
def start_run():
    domain = request.form.get("domain", "").strip().lower()
    if not domain:
        return redirect(url_for("index"))

    modules = set(request.form.getlist("modules")) or {"subdomains", "shodan", "emails"}
    homoglyph = request.form.get("homoglyph") == "on"
    skip_ai = "ai" not in request.form.getlist("modules_ai")

    known_names_raw = request.form.get("known_names", "")
    known_names = [n.strip() for n in known_names_raw.splitlines() if n.strip()] or None

    job_id = uuid.uuid4().hex[:12]
    JOBS[job_id] = {
        "status": "running",
        "log": [],
        "data": None,
        "error": None,
        "domain": domain,
    }

    def worker():
        def log(msg: str) -> None:
            JOBS[job_id]["log"].append(msg)

        try:
            data = run_full(
                domain,
                shodan_key=_env("SHODAN_API_KEY"),
                hunter_key=_env("HUNTER_API_KEY"),
                anthropic_key=_env("ANTHROPIC_API_KEY"),
                known_names=known_names,
                skip_ai=skip_ai,
                modules=modules,
                github_token=_env("GITHUB_TOKEN"),
                homoglyph=homoglyph,
                log=log,
            )
            JOBS[job_id]["data"] = data
            JOBS[job_id]["status"] = "done"
        except Exception:
            JOBS[job_id]["status"] = "error"
            JOBS[job_id]["error"] = traceback.format_exc()

    threading.Thread(target=worker, daemon=True).start()
    return redirect(url_for("status_page", job_id=job_id))


@app.route("/run-portscan", methods=["POST"])
def start_portscan():
    targets_raw = request.form.get("targets", "")
    targets = [t.strip() for t in targets_raw.splitlines() if t.strip()]
    authorized_checkbox = request.form.get("ps_authorized_checkbox") == "on"
    confirm_text = request.form.get("ps_confirm_text", "").strip()

    if not targets or not authorized_checkbox or confirm_text != "AUTHORIZED":
        return render_template(
            "index.html",
            **_index_ctx(
                ps_error="You must enter at least one target, check the authorization box, "
                         "and type AUTHORIZED exactly to run a port scan."
            ),
        )

    job_id = uuid.uuid4().hex[:12]
    JOBS[job_id] = {
        "status": "running",
        "log": [f"Starting TCP-connect port scan of {len(targets)} target(s)..."],
        "data": None,
        "error": None,
        "domain": ", ".join(targets),
        "kind": "portscan",
    }

    def worker():
        try:
            result = port_scan.run(targets)
            JOBS[job_id]["data"] = result
            JOBS[job_id]["log"].append(
                f"{len(result['open_ports'])} open ports found (engine: {result['engine']})."
            )
            for e in result.get("errors", []):
                JOBS[job_id]["log"].append(f"Note: {e}")
            JOBS[job_id]["status"] = "done"
        except Exception:
            JOBS[job_id]["status"] = "error"
            JOBS[job_id]["error"] = traceback.format_exc()

    threading.Thread(target=worker, daemon=True).start()
    return redirect(url_for("status_page", job_id=job_id))


@app.route("/run-directories", methods=["POST"])
def start_directories():
    target_url = request.form.get("target_url", "").strip()
    authorized_checkbox = request.form.get("authorized_checkbox") == "on"
    confirm_text = request.form.get("confirm_text", "").strip()
    valid_only = request.form.get("valid_only") == "on"

    if not target_url or not authorized_checkbox or confirm_text != "AUTHORIZED":
        return render_template(
            "index.html",
            **_index_ctx(
                dir_error="You must check the authorization box and type AUTHORIZED exactly to run active directory enumeration."
            ),
        )

    job_id = uuid.uuid4().hex[:12]
    JOBS[job_id] = {
        "status": "running",
        "log": [f"Starting active directory enumeration against {target_url}..."],
        "data": None,
        "error": None,
        "domain": target_url,
        "kind": "directories",
    }

    def worker():
        try:
            result = dir_enum.run(target_url, valid_only=valid_only)
            JOBS[job_id]["data"] = result
            JOBS[job_id]["log"].append(
                f"Found {len(result['results'])} responsive paths."
            )
            for e in result.get("errors", []):
                JOBS[job_id]["log"].append(f"Note: {e}")
            JOBS[job_id]["status"] = "done"
        except Exception:
            JOBS[job_id]["status"] = "error"
            JOBS[job_id]["error"] = traceback.format_exc()

    threading.Thread(target=worker, daemon=True).start()
    return redirect(url_for("status_page", job_id=job_id))


@app.route("/status/<job_id>")
def status_page(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        return "Job not found", 404
    return render_template("status.html", job_id=job_id, domain=job["domain"])


@app.route("/api/status/<job_id>")
def api_status(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        return jsonify({"status": "not_found"}), 404
    return jsonify({"status": job["status"], "log": job["log"], "error": job["error"]})


@app.route("/results/<job_id>")
def results_page(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        return "Job not found", 404
    if job["status"] == "error":
        return render_template(
            "status.html", job_id=job_id, domain=job["domain"], error=job["error"]
        )
    if job["status"] != "done":
        return redirect(url_for("status_page", job_id=job_id))
    if job.get("kind") == "directories":
        return render_template(
            "dir_results.html", job_id=job_id, target=job["domain"], data=job["data"]
        )
    if job.get("kind") == "portscan":
        return render_template(
            "port_results.html", job_id=job_id, target=job["domain"], data=job["data"]
        )
    return render_template("results.html", job_id=job_id, domain=job["domain"])


@app.route("/report/<job_id>")
def report(job_id: str):
    job = JOBS.get(job_id)
    if not job or job["status"] != "done":
        return "Report not ready", 404
    return Response(render_html(job["data"]), mimetype="text/html")


@app.route("/download/<job_id>/<fmt>")
def download(job_id: str, fmt: str):
    job = JOBS.get(job_id)
    if not job or job["status"] != "done":
        return "Not ready", 404

    if job.get("kind") in ("directories", "portscan") or fmt == "json":
        return Response(
            render_json(job["data"]),
            mimetype="application/json",
            headers={
                "Content-Disposition": f'attachment; filename="{job["domain"]}_recon.json"'
            },
        )
    return Response(
        render_html(job["data"]),
        mimetype="text/html",
        headers={
            "Content-Disposition": f'attachment; filename="{job["domain"]}_report.html"'
        },
    )


def main():
    port = int(os.environ.get("POINTDEXTER_GUI_PORT", 5151))
    print(f"Pointdexter GUI running at http://127.0.0.1:{port}")
    app.run(host="127.0.0.1", port=port, debug=False)


if __name__ == "__main__":
    main()
